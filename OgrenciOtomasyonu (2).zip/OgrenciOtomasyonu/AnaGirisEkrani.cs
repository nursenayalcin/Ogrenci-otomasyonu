using System;
using System.Drawing;
using System.Windows.Forms;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class AnaGirisEkrani : Form
    {
        public AnaGirisEkrani()
        {
            Text = "Ogrenci Otomasyonu Sistemi"; Size = new Size(800, 600); S.Apply(this);
            var top = new Panel { Dock = DockStyle.Top, Height = 70, BackColor = Color.FromArgb(40, 40, 40) };
            var t = S.Lbl("OGRENCI OTOMASYONU SISTEMI", S.H1); t.ForeColor = S.Accent; t.Location = new Point(150, 20); top.Controls.Add(t);
            var info = S.Btn("BILGI / YARDIM", S.BtnDef, 140, 35); info.Location = new Point(630, 18); info.Font = S.Small;
            info.Click += (s, e) => MessageBox.Show("Ogrenci Otomasyonu Sistemi v2.0\n\nKirikhan MYO - Bilgisayar Teknolojisi\nSistem Analizi ve Tasarimi Dersi\n2025-2026 Bahar", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            top.Controls.Add(info); Controls.Add(top);

            var p = S.Pnl(350, 280); p.Location = new Point(225, 160);
            var b1 = S.Btn("OGRENCI GIRISI", S.BtnDef, 260, 50); b1.Location = new Point(45, 40);
            b1.Click += (s, e) => new LoginEkrani("Ogrenci").ShowDialog(); p.Controls.Add(b1);
            var b2 = S.Btn("AKADEMISYEN GIRISI", S.BtnDef, 260, 50); b2.Location = new Point(45, 110);
            b2.Click += (s, e) => new LoginEkrani("Akademisyen").ShowDialog(); p.Controls.Add(b2);
            var b3 = S.Btn("OGRENCI ISLERI (ADMIN) GIRISI", S.BtnDef, 260, 50); b3.Location = new Point(45, 180);
            b3.Click += (s, e) => new LoginEkrani("Admin").ShowDialog(); p.Controls.Add(b3);
            Controls.Add(p);
        }
    }
}
