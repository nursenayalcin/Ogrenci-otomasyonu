using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class AdminMenuEkrani : Form
    {
        public AdminMenuEkrani(string user)
        {
            Text=$"Admin Paneli - {user}";Size=new Size(650,650);S.Apply(this);
            var tp=new Panel{Dock=DockStyle.Top,Height=60,BackColor=Color.FromArgb(40,40,40)};
            var t=S.Lbl("Admin Paneli",S.H1);t.ForeColor=S.Accent;t.Location=new Point(220,15);tp.Controls.Add(t);Controls.Add(tp);
            var ul=S.Lbl($"Hos geldiniz: {user}",S.Small);ul.ForeColor=S.Dim;ul.Location=new Point(240,75);Controls.Add(ul);
            int bw=260,bh=45,sx=190,sy=105,g=55;
            AB("Ogrenci Islemleri",S.BtnDef,sx,sy,bw,bh,()=>Nav.Git(this,new OgrenciListesiEkrani()));
            AB("Ders Islemleri",S.BtnDef,sx,sy+g,bw,bh,()=>Nav.Git(this,new DersYonetimiEkrani()));
            AB("Not Islemleri",S.BtnDef,sx,sy+g*2,bw,bh,()=>Nav.Git(this,new NotGirisEkrani(0)));
            AB("Ogretmen Islemleri",S.BtnDef,sx,sy+g*3,bw,bh,()=>Nav.Git(this,new OgretmenListesiEkrani()));
            AB("Bolum Ekle",S.BtnOrange,sx,sy+g*4,bw,bh,()=>Nav.Git(this,new BolumEkleEkrani()));
            AB("Kullanici Olustur",S.BtnOrange,sx,sy+g*5,bw,bh,()=>Nav.Git(this,new KullaniciOlusturEkrani()));
            AB("Devamsizlik Islemleri",S.BtnBlue,sx,sy+g*6,bw,bh,()=>Nav.Git(this,new DevamsizlikEkrani()));
            AB("Rapor Goruntule",S.BtnBlue,sx,sy+g*7,bw,bh,()=>Nav.Git(this,new RaporEkrani()));
            AB("Cikis",S.BtnRed,sx,sy+g*8,bw,bh,()=>Close());
        }
        void AB(string t,Color c,int x,int y,int w,int h,Action a){var b=S.Btn(t,c,w,h);b.Location=new Point(x,y);b.Click+=(s,e)=>a();Controls.Add(b);}
    }

    // OGRENCI LISTESI - soft delete duzeltildi
    public class OgrenciListesiEkrani : Form
    {
        private DataGridView dgv;private TextBox txtAra;
        public OgrenciListesiEkrani()
        {
            Text="Ogrenci Listesi";Size=new Size(850,580);S.Apply(this);
            var t=S.Lbl("Ogrenci Listesi",S.H1);t.ForeColor=S.Accent;t.Location=new Point(310,10);Controls.Add(t);
            Controls.Add(S.FLbl("Arama:",50,55));txtAra=S.Tb(350);txtAra.Location=new Point(130,53);txtAra.TextChanged+=(s,e)=>Yukle();Controls.Add(txtAra);
            dgv=S.Dgv();dgv.Location=new Point(25,90);dgv.Size=new Size(790,340);Controls.Add(dgv);
            var eb=S.Btn("Ogrenci Ekle",S.BtnGreen,200,40);eb.Location=new Point(30,445);eb.Click+=(s,e)=>{Nav.GitDialog(new OgrenciEkleEkrani());Yukle();};Controls.Add(eb);
            var gb=S.Btn("Guncelle",S.BtnBlue,200,40);gb.Location=new Point(260,445);gb.Click+=(s,e)=>{if(dgv.SelectedRows.Count>0){Nav.GitDialog(new OgrenciEkleEkrani(CInt("OgrenciID")));Yukle();}};Controls.Add(gb);
            // Soft delete: sadece Aktif=0 yapar, veriyi silmez
            var sb=S.Btn("Pasif Yap",S.BtnOrange,200,40);sb.Location=new Point(490,445);
            sb.Click+=(s,e)=>{if(dgv.SelectedRows.Count==0)return;if(MessageBox.Show("Ogrenci pasif yapilacak (silinmeyecek). Emin misiniz?","Onay",MessageBoxButtons.YesNo)==DialogResult.Yes){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("UPDATE Ogrenciler SET Aktif=0 WHERE OgrenciID=@id",cn);cmd.Parameters.AddWithValue("@id",CInt("OgrenciID"));cmd.ExecuteNonQuery();Yukle();MessageBox.Show("Ogrenci pasif yapildi. Verileri korunmaktadir.");}catch(Exception ex){MessageBox.Show(ex.Message);}}};Controls.Add(sb);
            var geri=S.Btn("Geri",S.BtnDef,100,40);geri.Location=new Point(720,445);geri.Click+=(s,e)=>Close();Controls.Add(geri);
            Yukle();
        }
        int CInt(string col)=>Convert.ToInt32(dgv.SelectedRows[0].Cells[col].Value);
        void Yukle(){try{using var cn=Db.Baglanti();cn.Open();string sql=@"SELECT o.OgrenciID,o.OgrenciNo AS[Ogrenci No],o.Ad,o.Soyad,b.BolumAdi AS[Bolum],o.Sinif,o.Telefon,o.Email FROM Ogrenciler o INNER JOIN Bolumler b ON o.BolumID=b.BolumID WHERE o.Aktif=1";if(!string.IsNullOrWhiteSpace(txtAra.Text))sql+=" AND(o.Ad+' '+o.Soyad LIKE @a OR o.OgrenciNo LIKE @a OR b.BolumAdi LIKE @a)";sql+=" ORDER BY o.OgrenciNo";using var cmd=new SqlCommand(sql,cn);if(!string.IsNullOrWhiteSpace(txtAra.Text))cmd.Parameters.AddWithValue("@a",$"%{txtAra.Text}%");var dt=new DataTable();dt.Load(cmd.ExecuteReader());dgv.DataSource=dt;if(dgv.Columns.Contains("OgrenciID"))dgv.Columns["OgrenciID"].Visible=false;}catch(Exception ex){MessageBox.Show(Db.Hata(ex));}}
    }

    public class OgrenciEkleEkrani : Form
    {
        private TextBox txtNo,txtAd,txtSoyad,txtSinif,txtTel,txtEmail;private ComboBox cmbBolum;private DateTimePicker dtpDogum;private int? id;
        public OgrenciEkleEkrani(int? ogrId=null)
        {
            id=ogrId;bool upd=id.HasValue;Text=upd?"Ogrenci Guncelle":"Ogrenci Ekle";Size=new Size(500,580);S.Apply(this);
            var t=S.Lbl(Text,S.H1);t.ForeColor=S.Accent;t.Location=new Point(130,10);Controls.Add(t);
            var p=S.Pnl(420,400);p.Location=new Point(35,50);int lx=25,tx=155,y=15,g=50;
            p.Controls.Add(S.FLbl("Ogrenci No:",lx,y));txtNo=S.Tb(220);txtNo.Location=new Point(tx,y);p.Controls.Add(txtNo);
            y+=g;p.Controls.Add(S.FLbl("Ad:",lx,y));txtAd=S.Tb(220);txtAd.Location=new Point(tx,y);p.Controls.Add(txtAd);
            y+=g;p.Controls.Add(S.FLbl("Soyad:",lx,y));txtSoyad=S.Tb(220);txtSoyad.Location=new Point(tx,y);p.Controls.Add(txtSoyad);
            y+=g;p.Controls.Add(S.FLbl("Dogum Tarihi:",lx,y));dtpDogum=new DateTimePicker{Location=new Point(tx,y),Size=new Size(220,30),Format=DateTimePickerFormat.Short};p.Controls.Add(dtpDogum);
            y+=g;p.Controls.Add(S.FLbl("Bolum:",lx,y));cmbBolum=S.Cmb(220);cmbBolum.Location=new Point(tx,y);p.Controls.Add(cmbBolum);
            y+=g;p.Controls.Add(S.FLbl("Sinif:",lx,y));txtSinif=S.Tb(80);txtSinif.Location=new Point(tx,y);p.Controls.Add(txtSinif);
            y+=g;p.Controls.Add(S.FLbl("Telefon:",lx,y));txtTel=S.Tb(220);txtTel.Location=new Point(tx,y);p.Controls.Add(txtTel);
            y+=g;p.Controls.Add(S.FLbl("Email:",lx,y));txtEmail=S.Tb(220);txtEmail.Location=new Point(tx,y);p.Controls.Add(txtEmail);
            Controls.Add(p);
            var kb=S.Btn("KAYDET",S.BtnGreen,160,40);kb.Location=new Point(80,465);kb.Click+=Kaydet;Controls.Add(kb);
            var ib=S.Btn("IPTAL",S.BtnRed,160,40);ib.Location=new Point(260,465);ib.Click+=(s,e)=>Close();Controls.Add(ib);
            try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT BolumID,BolumAdi FROM Bolumler ORDER BY BolumAdi",cn);using var rd=cmd.ExecuteReader();while(rd.Read())cmbBolum.Items.Add(new CItem{ID=rd.GetInt32(0),Ad=rd.GetString(1)});if(cmbBolum.Items.Count>0)cmbBolum.SelectedIndex=0;}catch{}
            if(upd){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT OgrenciNo,Ad,Soyad,DogumTarihi,BolumID,Sinif,Telefon,Email FROM Ogrenciler WHERE OgrenciID=@id",cn);cmd.Parameters.AddWithValue("@id",id!.Value);using var rd=cmd.ExecuteReader();if(rd.Read()){txtNo.Text=rd.GetString(0);txtNo.ReadOnly=true;txtAd.Text=rd.GetString(1);txtSoyad.Text=rd.GetString(2);if(!rd.IsDBNull(3))dtpDogum.Value=rd.GetDateTime(3);int bid=rd.GetInt32(4);for(int i=0;i<cmbBolum.Items.Count;i++)if(((CItem)cmbBolum.Items[i]).ID==bid){cmbBolum.SelectedIndex=i;break;}txtSinif.Text=rd.GetInt32(5).ToString();txtTel.Text=rd.IsDBNull(6)?"":rd.GetString(6);txtEmail.Text=rd.IsDBNull(7)?"":rd.GetString(7);}}catch{}}
        }
        void Kaydet(object? s,EventArgs e){
            if(string.IsNullOrWhiteSpace(txtNo.Text)||string.IsNullOrWhiteSpace(txtAd.Text)||string.IsNullOrWhiteSpace(txtSoyad.Text)||!int.TryParse(txtSinif.Text,out int sinif)){MessageBox.Show("Zorunlu alanlari doldurunuz!");return;}
            try{using var cn=Db.Baglanti();cn.Open();int bid=((CItem)cmbBolum.SelectedItem!).ID;
                if(id.HasValue){using var cmd=new SqlCommand("UPDATE Ogrenciler SET Ad=@ad,Soyad=@soy,DogumTarihi=@dt,BolumID=@b,Sinif=@s,Telefon=@t,Email=@e WHERE OgrenciID=@id",cn);cmd.Parameters.AddWithValue("@ad",txtAd.Text);cmd.Parameters.AddWithValue("@soy",txtSoyad.Text);cmd.Parameters.AddWithValue("@dt",dtpDogum.Value.Date);cmd.Parameters.AddWithValue("@b",bid);cmd.Parameters.AddWithValue("@s",sinif);cmd.Parameters.AddWithValue("@t",txtTel.Text);cmd.Parameters.AddWithValue("@e",txtEmail.Text);cmd.Parameters.AddWithValue("@id",id.Value);cmd.ExecuteNonQuery();MessageBox.Show("Guncellendi!");Close();}
                else{using var cmd=new SqlCommand("INSERT INTO Ogrenciler(OgrenciNo,Ad,Soyad,DogumTarihi,BolumID,Sinif,Telefon,Email)VALUES(@no,@ad,@soy,@dt,@b,@s,@t,@e)",cn);cmd.Parameters.AddWithValue("@no",txtNo.Text);cmd.Parameters.AddWithValue("@ad",txtAd.Text);cmd.Parameters.AddWithValue("@soy",txtSoyad.Text);cmd.Parameters.AddWithValue("@dt",dtpDogum.Value.Date);cmd.Parameters.AddWithValue("@b",bid);cmd.Parameters.AddWithValue("@s",sinif);cmd.Parameters.AddWithValue("@t",txtTel.Text);cmd.Parameters.AddWithValue("@e",txtEmail.Text);cmd.ExecuteNonQuery();MessageBox.Show("Eklendi!");Close();}
            }catch(SqlException ex)when(ex.Number==2627){MessageBox.Show("Bu ogrenci no zaten kayitli!");}catch(Exception ex){MessageBox.Show(ex.Message);}
        }
    }

    public class BolumEkleEkrani : Form
    {
        private TextBox txtAd,txtKod;private DataGridView dgv;
        public BolumEkleEkrani(){Text="Bolum Yonetimi";Size=new Size(550,480);S.Apply(this);var t=S.Lbl("Bolum Yonetimi",S.H2);t.ForeColor=S.Accent;t.Location=new Point(170,10);Controls.Add(t);var p=S.Pnl(470,100);p.Location=new Point(35,45);p.Controls.Add(S.FLbl("Bolum Adi:",15,15));txtAd=S.Tb(250);txtAd.Location=new Point(130,15);p.Controls.Add(txtAd);p.Controls.Add(S.FLbl("Bolum Kodu:",15,55));txtKod=S.Tb(80);txtKod.Location=new Point(130,55);p.Controls.Add(txtKod);var eb=S.Btn("Ekle",S.BtnGreen,100,35);eb.Location=new Point(350,55);eb.Click+=Ekle;p.Controls.Add(eb);Controls.Add(p);dgv=S.Dgv();dgv.Location=new Point(35,160);dgv.Size=new Size(470,230);Controls.Add(dgv);var geri=S.Btn("Geri",S.BtnDef,120,35);geri.Location=new Point(35,400);geri.Click+=(s,e)=>Close();Controls.Add(geri);Yukle();}
        void Yukle(){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT BolumID,BolumKodu AS[Kod],BolumAdi AS[Bolum Adi]FROM Bolumler ORDER BY BolumAdi",cn);var dt=new DataTable();dt.Load(cmd.ExecuteReader());dgv.DataSource=dt;if(dgv.Columns.Contains("BolumID"))dgv.Columns["BolumID"].Visible=false;}catch{}}
        void Ekle(object? s,EventArgs e){if(string.IsNullOrWhiteSpace(txtAd.Text)||string.IsNullOrWhiteSpace(txtKod.Text)){MessageBox.Show("Alanlari doldurunuz!");return;}try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("INSERT INTO Bolumler(BolumAdi,BolumKodu)VALUES(@a,@k)",cn);cmd.Parameters.AddWithValue("@a",txtAd.Text);cmd.Parameters.AddWithValue("@k",txtKod.Text.ToUpper());cmd.ExecuteNonQuery();txtAd.Clear();txtKod.Clear();Yukle();MessageBox.Show("Bolum eklendi!");}catch(SqlException ex)when(ex.Number==2627){MessageBox.Show("Bu bolum zaten var!");}catch(Exception ex){MessageBox.Show(ex.Message);}}
    }

    public class KullaniciOlusturEkrani : Form
    {
        private TextBox txtUser,txtPass;private ComboBox cmbRol,cmbIlgili;
        public KullaniciOlusturEkrani(){Text="Kullanici Olustur";Size=new Size(450,350);S.Apply(this);var t=S.Lbl("Kullanici Olustur",S.H2);t.ForeColor=S.Accent;t.Location=new Point(120,10);Controls.Add(t);var p=S.Pnl(390,210);p.Location=new Point(25,45);int lx=15,tx=140,y=15,g=48;p.Controls.Add(S.FLbl("Kullanici Adi:",lx,y));txtUser=S.Tb(210);txtUser.Location=new Point(tx,y);p.Controls.Add(txtUser);y+=g;p.Controls.Add(S.FLbl("Sifre:",lx,y));txtPass=S.Tb(210);txtPass.Location=new Point(tx,y);p.Controls.Add(txtPass);y+=g;p.Controls.Add(S.FLbl("Rol:",lx,y));cmbRol=S.Cmb(210);cmbRol.Location=new Point(tx,y);cmbRol.Items.AddRange(new[]{"Ogrenci","Akademisyen","Admin"});cmbRol.SelectedIndex=0;cmbRol.SelectedIndexChanged+=(s,e)=>IY();p.Controls.Add(cmbRol);y+=g;p.Controls.Add(S.FLbl("Ilgili Kisi:",lx,y));cmbIlgili=S.Cmb(210);cmbIlgili.Location=new Point(tx,y);p.Controls.Add(cmbIlgili);Controls.Add(p);var kb=S.Btn("Olustur",S.BtnGreen,150,38);kb.Location=new Point(60,270);kb.Click+=Ol;Controls.Add(kb);var ib=S.Btn("Geri",S.BtnDef,150,38);ib.Location=new Point(230,270);ib.Click+=(s,e)=>Close();Controls.Add(ib);IY();}
        void IY(){cmbIlgili.Items.Clear();string r=cmbRol.SelectedItem?.ToString()??"";if(r=="Admin"){cmbIlgili.Items.Add(new CItem{ID=0,Ad="- Yok -"});cmbIlgili.SelectedIndex=0;return;}try{using var cn=Db.Baglanti();cn.Open();string sql=r=="Ogrenci"?"SELECT OgrenciID,OgrenciNo+' - '+Ad+' '+Soyad FROM Ogrenciler WHERE Aktif=1 ORDER BY Soyad":"SELECT OgretmenID,ISNULL(Unvan+' ','')+Ad+' '+Soyad FROM Ogretmenler ORDER BY Soyad";using var cmd=new SqlCommand(sql,cn);using var rd=cmd.ExecuteReader();while(rd.Read())cmbIlgili.Items.Add(new CItem{ID=rd.GetInt32(0),Ad=rd.GetString(1)});if(cmbIlgili.Items.Count>0)cmbIlgili.SelectedIndex=0;}catch{}}
        void Ol(object? s,EventArgs e){if(string.IsNullOrWhiteSpace(txtUser.Text)||string.IsNullOrWhiteSpace(txtPass.Text)){MessageBox.Show("Kullanici adi ve sifre zorunlu!");return;}try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("INSERT INTO Kullanicilar(KullaniciAdi,Sifre,Rol,IlgiliID)VALUES(@u,@p,@r,@i)",cn);cmd.Parameters.AddWithValue("@u",txtUser.Text);cmd.Parameters.AddWithValue("@p",txtPass.Text);cmd.Parameters.AddWithValue("@r",cmbRol.SelectedItem!.ToString()!);int il=cmbIlgili.SelectedIndex>=0?((CItem)cmbIlgili.SelectedItem!).ID:0;cmd.Parameters.AddWithValue("@i",il==0?(object)DBNull.Value:il);cmd.ExecuteNonQuery();MessageBox.Show("Kullanici olusturuldu!");Close();}catch(SqlException ex)when(ex.Number==2627){MessageBox.Show("Bu kullanici adi zaten var!");}catch(Exception ex){MessageBox.Show(ex.Message);}}
    }

    public class DevamsizlikEkrani : Form
    {
        private ComboBox cmbOgr,cmbDers,cmbDurum;private DateTimePicker dtpTarih;private TextBox txtAciklama;private DataGridView dgv;
        public DevamsizlikEkrani(){Text="Devamsizlik Islemleri";Size=new Size(800,580);S.Apply(this);var t=S.Lbl("Devamsizlik Islemleri",S.H2);t.ForeColor=S.Accent;t.Location=new Point(270,8);Controls.Add(t);var p=S.Pnl(720,130);p.Location=new Point(35,40);p.Controls.Add(S.FLbl("Ogrenci:",10,10));cmbOgr=S.Cmb(250);cmbOgr.Location=new Point(100,10);p.Controls.Add(cmbOgr);p.Controls.Add(S.FLbl("Ders:",380,10));cmbDers=S.Cmb(200);cmbDers.Location=new Point(430,10);p.Controls.Add(cmbDers);p.Controls.Add(S.FLbl("Tarih:",10,50));dtpTarih=new DateTimePicker{Location=new Point(100,50),Size=new Size(150,30),Format=DateTimePickerFormat.Short};p.Controls.Add(dtpTarih);p.Controls.Add(S.FLbl("Durum:",280,50));cmbDurum=S.Cmb(120);cmbDurum.Location=new Point(350,50);cmbDurum.Items.AddRange(new[]{"Geldi","Gelmedi","Izinli"});cmbDurum.SelectedIndex=0;p.Controls.Add(cmbDurum);p.Controls.Add(S.FLbl("Aciklama:",500,50));txtAciklama=S.Tb(170);txtAciklama.Location=new Point(580,50);p.Controls.Add(txtAciklama);var eb=S.Btn("Kaydet",S.BtnGreen,120,35);eb.Location=new Point(300,90);eb.Click+=Kay;p.Controls.Add(eb);Controls.Add(p);dgv=S.Dgv();dgv.Location=new Point(35,185);dgv.Size=new Size(720,330);Controls.Add(dgv);var geri=S.Btn("Geri",S.BtnDef,120,35);geri.Location=new Point(340,525);geri.Click+=(s,e)=>Close();Controls.Add(geri);CY();Yukle();}
        void CY(){try{using var cn=Db.Baglanti();cn.Open();using(var cmd=new SqlCommand("SELECT OgrenciID,OgrenciNo+' - '+Ad+' '+Soyad FROM Ogrenciler WHERE Aktif=1 ORDER BY Soyad",cn))using(var rd=cmd.ExecuteReader())while(rd.Read())cmbOgr.Items.Add(new CItem{ID=rd.GetInt32(0),Ad=rd.GetString(1)});if(cmbOgr.Items.Count>0)cmbOgr.SelectedIndex=0;using(var cmd=new SqlCommand("SELECT DersID,DersKodu+' - '+DersAdi FROM Dersler ORDER BY DersKodu",cn))using(var rd=cmd.ExecuteReader())while(rd.Read())cmbDers.Items.Add(new CItem{ID=rd.GetInt32(0),Ad=rd.GetString(1)});if(cmbDers.Items.Count>0)cmbDers.SelectedIndex=0;}catch{}}
        void Yukle(){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT dv.DevamsizlikID,o.Ad+' '+o.Soyad AS[Ogrenci],d.DersKodu AS[Ders],dv.Tarih,dv.Durum,dv.Aciklama FROM Devamsizlik dv INNER JOIN Ogrenciler o ON dv.OgrenciID=o.OgrenciID INNER JOIN Dersler d ON dv.DersID=d.DersID ORDER BY dv.Tarih DESC",cn);var dt=new DataTable();dt.Load(cmd.ExecuteReader());dgv.DataSource=dt;if(dgv.Columns.Contains("DevamsizlikID"))dgv.Columns["DevamsizlikID"].Visible=false;}catch{}}
        void Kay(object? s,EventArgs e){if(cmbOgr.SelectedIndex<0||cmbDers.SelectedIndex<0)return;try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("IF EXISTS(SELECT 1 FROM Devamsizlik WHERE OgrenciID=@o AND DersID=@d AND Tarih=@t)UPDATE Devamsizlik SET Durum=@du,Aciklama=@a WHERE OgrenciID=@o AND DersID=@d AND Tarih=@t ELSE INSERT INTO Devamsizlik(OgrenciID,DersID,Tarih,Durum,Aciklama)VALUES(@o,@d,@t,@du,@a)",cn);cmd.Parameters.AddWithValue("@o",((CItem)cmbOgr.SelectedItem!).ID);cmd.Parameters.AddWithValue("@d",((CItem)cmbDers.SelectedItem!).ID);cmd.Parameters.AddWithValue("@t",dtpTarih.Value.Date);cmd.Parameters.AddWithValue("@du",cmbDurum.SelectedItem!.ToString()!);cmd.Parameters.AddWithValue("@a",string.IsNullOrEmpty(txtAciklama.Text)?(object)DBNull.Value:txtAciklama.Text);cmd.ExecuteNonQuery();Yukle();MessageBox.Show("Kaydedildi!");}catch(Exception ex){MessageBox.Show(ex.Message);}}
    }

    public class RaporEkrani : Form
    {
        public RaporEkrani(){Text="Rapor Goruntule";Size=new Size(750,550);S.Apply(this);var t=S.Lbl("Raporlar",S.H1);t.ForeColor=S.Accent;t.Location=new Point(310,8);Controls.Add(t);var dgv=S.Dgv();dgv.Location=new Point(30,50);dgv.Size=new Size(680,200);Controls.Add(dgv);var lbl1=S.Lbl("Bolum Bazinda Ogrenci Sayilari",S.FldF);lbl1.ForeColor=S.Accent;lbl1.Location=new Point(220,260);Controls.Add(lbl1);var dgv2=S.Dgv();dgv2.Location=new Point(30,290);dgv2.Size=new Size(680,180);Controls.Add(dgv2);try{using var cn=Db.Baglanti();cn.Open();using(var cmd=new SqlCommand("SELECT 'Toplam Ogrenci' AS Bilgi,(SELECT COUNT(*)FROM Ogrenciler WHERE Aktif=1)AS Sayi UNION ALL SELECT 'Toplam Ogretmen',(SELECT COUNT(*)FROM Ogretmenler) UNION ALL SELECT 'Toplam Ders',(SELECT COUNT(*)FROM Dersler) UNION ALL SELECT 'Toplam Bolum',(SELECT COUNT(*)FROM Bolumler) UNION ALL SELECT 'Toplam Not Kaydi',(SELECT COUNT(*)FROM Notlar) UNION ALL SELECT 'Toplam Devamsizlik',(SELECT COUNT(*)FROM Devamsizlik) UNION ALL SELECT 'Aktif Kullanici',(SELECT COUNT(*)FROM Kullanicilar WHERE Aktif=1)",cn)){var dt=new DataTable();dt.Load(cmd.ExecuteReader());dgv.DataSource=dt;}using(var cmd=new SqlCommand("SELECT b.BolumAdi AS[Bolum],COUNT(o.OgrenciID)AS[Ogrenci],(SELECT COUNT(*)FROM Dersler d WHERE d.BolumID=b.BolumID)AS[Ders],(SELECT COUNT(*)FROM Ogretmenler t WHERE t.BolumID=b.BolumID)AS[Ogretmen] FROM Bolumler b LEFT JOIN Ogrenciler o ON b.BolumID=o.BolumID AND o.Aktif=1 GROUP BY b.BolumID,b.BolumAdi ORDER BY b.BolumAdi",cn)){var dt=new DataTable();dt.Load(cmd.ExecuteReader());dgv2.DataSource=dt;}}catch(Exception ex){MessageBox.Show(ex.Message);}var geri=S.Btn("Geri",S.BtnDef,120,35);geri.Location=new Point(310,490);geri.Click+=(s,e)=>Close();Controls.Add(geri);}
    }
}
