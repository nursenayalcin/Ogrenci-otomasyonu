using System;
using System.Drawing;
using System.Windows.Forms;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class AdminMenuEkrani : Form
    {
        public AdminMenuEkrani(string user)
        {
            Text = $"Admin Paneli - {user}"; Size = new Size(650, 650); S.Apply(this);
            var tp = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(40, 40, 40) };
            var t = S.Lbl("Admin Paneli", S.H1); t.ForeColor = S.Accent; t.Location = new Point(220, 15); tp.Controls.Add(t); Controls.Add(tp);
            var ul = S.Lbl($"Hos geldiniz: {user}", S.Small); ul.ForeColor = S.Dim; ul.Location = new Point(240, 75); Controls.Add(ul);

            int bw = 260, bh = 45, sx = 190, sy = 105, g = 55;
            AddBtn("Ogrenci Islemleri", S.BtnDef, sx, sy, bw, bh, () => new OgrenciListesiEkrani().ShowDialog());
            AddBtn("Ders Islemleri", S.BtnDef, sx, sy + g, bw, bh, () => new DersYonetimiEkrani().ShowDialog());
            AddBtn("Not Islemleri", S.BtnDef, sx, sy + g * 2, bw, bh, () => new NotGirisEkrani().ShowDialog());
            AddBtn("Ogretmen Islemleri", S.BtnDef, sx, sy + g * 3, bw, bh, () => new OgretmenListesiEkrani().ShowDialog());
            AddBtn("Bolum Ekle", S.BtnOrange, sx, sy + g * 4, bw, bh, () => new BolumEkleEkrani().ShowDialog());
            AddBtn("Kullanici Olustur", S.BtnOrange, sx, sy + g * 5, bw, bh, () => new KullaniciOlusturEkrani().ShowDialog());
            AddBtn("Devamsizlik Islemleri", S.BtnBlue, sx, sy + g * 6, bw, bh, () => new DevamsizlikEkrani().ShowDialog());
            AddBtn("Rapor Goruntule", S.BtnBlue, sx, sy + g * 7, bw, bh, () => new RaporEkrani().ShowDialog());
            AddBtn("Cikis", S.BtnRed, sx, sy + g * 8, bw, bh, () => Close());
        }
        private void AddBtn(string t, Color c, int x, int y, int w, int h, Action act)
        { var b = S.Btn(t, c, w, h); b.Location = new Point(x, y); b.Click += (s, e) => act(); Controls.Add(b); }
    }
}
