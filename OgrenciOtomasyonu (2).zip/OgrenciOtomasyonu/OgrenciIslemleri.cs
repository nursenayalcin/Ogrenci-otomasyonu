using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class OgrenciListesiEkrani : Form
    {
        private DataGridView dgv; private TextBox txtAra;
        public OgrenciListesiEkrani()
        {
            Text = "Ogrenci Listesi"; Size = new Size(850, 580); S.Apply(this);
            var t = S.Lbl("Ogrenci Listesi", S.H1); t.ForeColor = S.Accent; t.Location = new Point(310, 10); Controls.Add(t);
            Controls.Add(S.FLbl("Arama:", 50, 55)); txtAra = S.Tb(350); txtAra.Location = new Point(130, 53); txtAra.TextChanged += (s, e) => Yukle(); Controls.Add(txtAra);
            dgv = S.Dgv(); dgv.Location = new Point(25, 90); dgv.Size = new Size(790, 340); Controls.Add(dgv);

            var eb = S.Btn("Ogrenci Ekle", S.BtnGreen, 220, 40); eb.Location = new Point(30, 445); eb.Click += (s, e) => { new OgrenciEkleEkrani().ShowDialog(); Yukle(); }; Controls.Add(eb);
            var gb = S.Btn("Guncelle", S.BtnBlue, 220, 40); gb.Location = new Point(280, 445);
            gb.Click += (s, e) => { if (dgv.SelectedRows.Count > 0) { new OgrenciEkleEkrani(Convert.ToInt32(dgv.SelectedRows[0].Cells["OgrenciID"].Value)).ShowDialog(); Yukle(); } }; Controls.Add(gb);
            var sb = S.Btn("Sil", S.BtnRed, 220, 40); sb.Location = new Point(530, 445);
            sb.Click += (s, e) =>
            {
                if (dgv.SelectedRows.Count == 0) return;
                if (MessageBox.Show("Silmek istediginize emin misiniz?", "Onay", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    try
                    {
                        using var cn = Db.Baglanti(); cn.Open();
                        using var cmd = new SqlCommand("UPDATE Ogrenciler SET Aktif=0 WHERE OgrenciID=@id", cn);
                        cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgv.SelectedRows[0].Cells["OgrenciID"].Value)); cmd.ExecuteNonQuery(); Yukle();
                    }
                    catch (Exception ex) { MessageBox.Show(ex.Message); }
                }
            }; Controls.Add(sb); Yukle();
        }
        private void Yukle()
        {
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                string sql = @"SELECT o.OgrenciID,o.OgrenciNo AS[Ogrenci No],o.Ad,o.Soyad,b.BolumAdi AS[Bolum],o.Sinif,o.Telefon,o.Email FROM Ogrenciler o INNER JOIN Bolumler b ON o.BolumID=b.BolumID WHERE o.Aktif=1";
                if (!string.IsNullOrWhiteSpace(txtAra.Text)) sql += " AND(o.Ad+' '+o.Soyad LIKE @a OR o.OgrenciNo LIKE @a OR b.BolumAdi LIKE @a)";
                sql += " ORDER BY o.OgrenciNo";
                using var cmd = new SqlCommand(sql, cn);
                if (!string.IsNullOrWhiteSpace(txtAra.Text)) cmd.Parameters.AddWithValue("@a", $"%{txtAra.Text}%");
                var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt;
                if (dgv.Columns.Contains("OgrenciID")) dgv.Columns["OgrenciID"].Visible = false;
            }
            catch (Exception ex) { MessageBox.Show(Db.HataMesaji(ex)); }
        }
    }

    public class OgrenciEkleEkrani : Form
    {
        private TextBox txtNo, txtAd, txtSoyad, txtSinif, txtTel, txtEmail;
        private ComboBox cmbBolum; private DateTimePicker dtpDogum; private int? id;
        public OgrenciEkleEkrani(int? ogrId = null)
        {
            id = ogrId; bool upd = id.HasValue;
            Text = upd ? "Ogrenci Guncelle" : "Ogrenci Ekle"; Size = new Size(500, 580); S.Apply(this);
            var t = S.Lbl(Text, S.H1); t.ForeColor = S.Accent; t.Location = new Point(130, 10); Controls.Add(t);
            var p = S.Pnl(420, 400); p.Location = new Point(35, 50);
            int lx = 25, tx = 155, y = 15, g = 50;

            p.Controls.Add(S.FLbl("Ogrenci No:", lx, y)); txtNo = S.Tb(220); txtNo.Location = new Point(tx, y); p.Controls.Add(txtNo);
            y += g; p.Controls.Add(S.FLbl("Ad:", lx, y)); txtAd = S.Tb(220); txtAd.Location = new Point(tx, y); p.Controls.Add(txtAd);
            y += g; p.Controls.Add(S.FLbl("Soyad:", lx, y)); txtSoyad = S.Tb(220); txtSoyad.Location = new Point(tx, y); p.Controls.Add(txtSoyad);
            y += g; p.Controls.Add(S.FLbl("Dogum Tarihi:", lx, y));
            dtpDogum = new DateTimePicker { Location = new Point(tx, y), Size = new Size(220, 30), Format = DateTimePickerFormat.Short }; p.Controls.Add(dtpDogum);
            y += g; p.Controls.Add(S.FLbl("Bolum:", lx, y)); cmbBolum = S.Cmb(220); cmbBolum.Location = new Point(tx, y); p.Controls.Add(cmbBolum);
            y += g; p.Controls.Add(S.FLbl("Sinif:", lx, y)); txtSinif = S.Tb(80); txtSinif.Location = new Point(tx, y); p.Controls.Add(txtSinif);
            y += g; p.Controls.Add(S.FLbl("Telefon:", lx, y)); txtTel = S.Tb(220); txtTel.Location = new Point(tx, y); p.Controls.Add(txtTel);
            y += g; p.Controls.Add(S.FLbl("Email:", lx, y)); txtEmail = S.Tb(220); txtEmail.Location = new Point(tx, y); p.Controls.Add(txtEmail);
            Controls.Add(p);

            var kb = S.Btn("KAYDET", S.BtnGreen, 160, 40); kb.Location = new Point(80, 465); kb.Click += Kaydet; Controls.Add(kb);
            var ib = S.Btn("IPTAL", S.BtnRed, 160, 40); ib.Location = new Point(260, 465); ib.Click += (s, e) => Close(); Controls.Add(ib);
            BolumYukle(); if (upd) Yukle();
        }
        private void BolumYukle() { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("SELECT BolumID,BolumAdi FROM Bolumler ORDER BY BolumAdi", cn); using var rd = cmd.ExecuteReader(); while (rd.Read()) cmbBolum.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbBolum.Items.Count > 0) cmbBolum.SelectedIndex = 0; } catch { } }
        private void Yukle()
        {
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using var cmd = new SqlCommand("SELECT OgrenciNo,Ad,Soyad,DogumTarihi,BolumID,Sinif,Telefon,Email FROM Ogrenciler WHERE OgrenciID=@id", cn);
                cmd.Parameters.AddWithValue("@id", id!.Value); using var rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    txtNo.Text = rd.GetString(0); txtNo.ReadOnly = true; txtAd.Text = rd.GetString(1); txtSoyad.Text = rd.GetString(2);
                    if (!rd.IsDBNull(3)) dtpDogum.Value = rd.GetDateTime(3);
                    int bid = rd.GetInt32(4); for (int i = 0; i < cmbBolum.Items.Count; i++) if (((CItem)cmbBolum.Items[i]).ID == bid) { cmbBolum.SelectedIndex = i; break; }
                    txtSinif.Text = rd.GetInt32(5).ToString(); txtTel.Text = rd.IsDBNull(6) ? "" : rd.GetString(6); txtEmail.Text = rd.IsDBNull(7) ? "" : rd.GetString(7);
                }
            }
            catch { }
        }
        private void Kaydet(object? s, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNo.Text) || string.IsNullOrWhiteSpace(txtAd.Text) || string.IsNullOrWhiteSpace(txtSoyad.Text) || !int.TryParse(txtSinif.Text, out int sinif))
            { MessageBox.Show("Zorunlu alanlari doldurunuz!"); return; }
            try
            {
                using var cn = Db.Baglanti(); cn.Open(); int bid = ((CItem)cmbBolum.SelectedItem!).ID;
                if (id.HasValue)
                {
                    using var cmd = new SqlCommand("UPDATE Ogrenciler SET Ad=@ad,Soyad=@soy,DogumTarihi=@dt,BolumID=@b,Sinif=@s,Telefon=@t,Email=@e WHERE OgrenciID=@id", cn);
                    cmd.Parameters.AddWithValue("@ad", txtAd.Text); cmd.Parameters.AddWithValue("@soy", txtSoyad.Text);
                    cmd.Parameters.AddWithValue("@dt", dtpDogum.Value.Date); cmd.Parameters.AddWithValue("@b", bid);
                    cmd.Parameters.AddWithValue("@s", sinif); cmd.Parameters.AddWithValue("@t", txtTel.Text);
                    cmd.Parameters.AddWithValue("@e", txtEmail.Text); cmd.Parameters.AddWithValue("@id", id.Value);
                    cmd.ExecuteNonQuery(); MessageBox.Show("Guncellendi!"); Close();
                }
                else
                {
                    using var cmd = new SqlCommand("INSERT INTO Ogrenciler(OgrenciNo,Ad,Soyad,DogumTarihi,BolumID,Sinif,Telefon,Email)VALUES(@no,@ad,@soy,@dt,@b,@s,@t,@e)", cn);
                    cmd.Parameters.AddWithValue("@no", txtNo.Text); cmd.Parameters.AddWithValue("@ad", txtAd.Text);
                    cmd.Parameters.AddWithValue("@soy", txtSoyad.Text); cmd.Parameters.AddWithValue("@dt", dtpDogum.Value.Date);
                    cmd.Parameters.AddWithValue("@b", bid); cmd.Parameters.AddWithValue("@s", sinif);
                    cmd.Parameters.AddWithValue("@t", txtTel.Text); cmd.Parameters.AddWithValue("@e", txtEmail.Text);
                    cmd.ExecuteNonQuery(); MessageBox.Show("Eklendi!"); Close();
                }
            }
            catch (SqlException ex) when (ex.Number == 2627) { MessageBox.Show("Bu ogrenci no zaten kayitli!"); }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
