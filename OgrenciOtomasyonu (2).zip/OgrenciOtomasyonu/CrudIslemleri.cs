using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class DersYonetimiEkrani : Form
    {
        private TextBox txtAd, txtKod, txtKredi; private ComboBox cmbOgrt, cmbBol; private DataGridView dgv;
        public DersYonetimiEkrani()
        {
            Text = "Ders Yonetimi"; Size = new Size(750, 620); S.Apply(this);
            var t = S.Lbl("Ders Yonetimi", S.H1); t.ForeColor = S.Accent; t.Location = new Point(280, 8); Controls.Add(t);
            var p = S.Pnl(660, 220); p.Location = new Point(40, 45);
            int lx = 25, tx = 145, y = 15, g = 40;
            p.Controls.Add(S.FLbl("Ders Adi:", lx, y)); txtAd = S.Tb(300); txtAd.Location = new Point(tx, y); p.Controls.Add(txtAd);
            y += g; p.Controls.Add(S.FLbl("Ders Kodu:", lx, y)); txtKod = S.Tb(120); txtKod.Location = new Point(tx, y); p.Controls.Add(txtKod);
            y += g; p.Controls.Add(S.FLbl("Kredi:", lx, y)); txtKredi = S.Tb(60); txtKredi.Location = new Point(tx, y); p.Controls.Add(txtKredi);
            y += g; p.Controls.Add(S.FLbl("Ogretmen:", lx, y)); cmbOgrt = S.Cmb(300); cmbOgrt.Location = new Point(tx, y); p.Controls.Add(cmbOgrt);
            y += g; p.Controls.Add(S.FLbl("Bolum:", lx, y)); cmbBol = S.Cmb(300); cmbBol.Location = new Point(tx, y); p.Controls.Add(cmbBol);
            var eb = S.Btn("Ders Ekle", S.BtnBlue, 130, 36); eb.Location = new Point(500, y); eb.Click += Ekle; p.Controls.Add(eb);
            Controls.Add(p);
            dgv = S.Dgv(); dgv.Location = new Point(40, 280); dgv.Size = new Size(660, 230); Controls.Add(dgv);
            var sb = S.Btn("Ders Sil", S.BtnRed, 140, 35); sb.Location = new Point(560, 520);
            sb.Click += (s, e) => { if (dgv.SelectedRows.Count == 0) return; if (MessageBox.Show("Silmek istediginize emin misiniz?", "Onay", MessageBoxButtons.YesNo) == DialogResult.Yes) { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("DELETE FROM Dersler WHERE DersID=@id", cn); cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgv.SelectedRows[0].Cells["DersID"].Value)); cmd.ExecuteNonQuery(); Yukle(); } catch (Exception ex) { MessageBox.Show(ex.Message); } } };
            Controls.Add(sb); CmbYukle(); Yukle();
        }
        private void CmbYukle() { try { using var cn = Db.Baglanti(); cn.Open(); using (var cmd = new SqlCommand("SELECT OgretmenID,ISNULL(Unvan+' ','')+Ad+' '+Soyad FROM Ogretmenler ORDER BY Soyad", cn)) using (var rd = cmd.ExecuteReader()) while (rd.Read()) cmbOgrt.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbOgrt.Items.Count > 0) cmbOgrt.SelectedIndex = 0; using (var cmd = new SqlCommand("SELECT BolumID,BolumAdi FROM Bolumler ORDER BY BolumAdi", cn)) using (var rd = cmd.ExecuteReader()) while (rd.Read()) cmbBol.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbBol.Items.Count > 0) cmbBol.SelectedIndex = 0; } catch { } }
        private void Yukle() { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("SELECT d.DersID,d.DersKodu AS[Ders Kodu],d.DersAdi AS[Ders Adi],d.Kredi,ISNULL(o.Ad+' '+o.Soyad,'-')AS[Ogretmen],b.BolumAdi AS[Bolum]FROM Dersler d LEFT JOIN Ogretmenler o ON d.OgretmenID=o.OgretmenID INNER JOIN Bolumler b ON d.BolumID=b.BolumID ORDER BY d.DersKodu", cn); var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt; if (dgv.Columns.Contains("DersID")) dgv.Columns["DersID"].Visible = false; } catch (Exception ex) { MessageBox.Show(ex.Message); } }
        private void Ekle(object? s, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAd.Text) || string.IsNullOrWhiteSpace(txtKod.Text) || !int.TryParse(txtKredi.Text, out int kr)) { MessageBox.Show("Alanlari doldurunuz!"); return; }
            try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("INSERT INTO Dersler(DersKodu,DersAdi,Kredi,OgretmenID,BolumID)VALUES(@k,@a,@kr,@o,@b)", cn); cmd.Parameters.AddWithValue("@k", txtKod.Text.ToUpper()); cmd.Parameters.AddWithValue("@a", txtAd.Text); cmd.Parameters.AddWithValue("@kr", kr); cmd.Parameters.AddWithValue("@o", cmbOgrt.SelectedIndex >= 0 ? ((CItem)cmbOgrt.SelectedItem!).ID : (object)DBNull.Value); cmd.Parameters.AddWithValue("@b", ((CItem)cmbBol.SelectedItem!).ID); cmd.ExecuteNonQuery(); txtAd.Clear(); txtKod.Clear(); txtKredi.Clear(); Yukle(); MessageBox.Show("Ders eklendi!"); } catch (SqlException ex) when (ex.Number == 2627) { MessageBox.Show("Bu ders kodu zaten var!"); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }

    public class NotGirisEkrani : Form
    {
        private ComboBox cmbOgr, cmbDers; private TextBox txtVize, txtFinal, txtOrt, txtHarf;
        public NotGirisEkrani()
        {
            Text = "Not Girisi"; Size = new Size(560, 520); S.Apply(this);
            var t = S.Lbl("Not Girisi", S.H1); t.ForeColor = S.Accent; t.Location = new Point(200, 8); Controls.Add(t);
            var p = S.Pnl(450, 340); p.Location = new Point(50, 50);
            int lx = 25, tx = 175, y = 20, g = 52;
            p.Controls.Add(S.FLbl("Ogrenci Sec:", lx, y)); cmbOgr = S.Cmb(230); cmbOgr.Location = new Point(tx, y); p.Controls.Add(cmbOgr);
            y += g; p.Controls.Add(S.FLbl("Ders Sec:", lx, y)); cmbDers = S.Cmb(230); cmbDers.Location = new Point(tx, y); p.Controls.Add(cmbDers);
            y += g; p.Controls.Add(S.FLbl("Vize Notu:", lx, y)); txtVize = S.Tb(120); txtVize.Location = new Point(tx, y); txtVize.TextChanged += Hesapla; p.Controls.Add(txtVize);
            y += g; p.Controls.Add(S.FLbl("Final Notu:", lx, y)); txtFinal = S.Tb(120); txtFinal.Location = new Point(tx, y); txtFinal.TextChanged += Hesapla; p.Controls.Add(txtFinal);
            y += g; p.Controls.Add(S.FLbl("Ortalama:", lx, y)); txtOrt = S.Tb(120); txtOrt.Location = new Point(tx, y); txtOrt.ReadOnly = true; txtOrt.BackColor = Color.FromArgb(50, 50, 50); p.Controls.Add(txtOrt);
            y += g; p.Controls.Add(S.FLbl("Harf Notu:", lx, y)); txtHarf = S.Tb(60); txtHarf.Location = new Point(tx, y); txtHarf.ReadOnly = true; txtHarf.BackColor = Color.FromArgb(50, 50, 50); txtHarf.Font = new Font("Segoe UI", 14, FontStyle.Bold); txtHarf.ForeColor = Color.LimeGreen; p.Controls.Add(txtHarf);
            Controls.Add(p);
            var kb = S.Btn("Kaydet", S.BtnGreen, 200, 45); kb.Location = new Point(175, 405); kb.Click += Kaydet; Controls.Add(kb);
            CmbYukle();
        }
        private void CmbYukle() { try { using var cn = Db.Baglanti(); cn.Open(); using (var cmd = new SqlCommand("SELECT OgrenciID,OgrenciNo+' - '+Ad+' '+Soyad FROM Ogrenciler WHERE Aktif=1 ORDER BY Soyad", cn)) using (var rd = cmd.ExecuteReader()) while (rd.Read()) cmbOgr.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbOgr.Items.Count > 0) cmbOgr.SelectedIndex = 0; using (var cmd = new SqlCommand("SELECT DersID,DersKodu+' - '+DersAdi FROM Dersler ORDER BY DersKodu", cn)) using (var rd = cmd.ExecuteReader()) while (rd.Read()) cmbDers.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbDers.Items.Count > 0) cmbDers.SelectedIndex = 0; } catch { } }
        private string HH(double o) => o >= 90 ? "AA" : o >= 85 ? "BA" : o >= 80 ? "BB" : o >= 75 ? "CB" : o >= 70 ? "CC" : o >= 65 ? "DC" : o >= 60 ? "DD" : o >= 50 ? "FD" : "FF";
        private void Hesapla(object? s, EventArgs e) { if (int.TryParse(txtVize.Text, out int v) && int.TryParse(txtFinal.Text, out int f)) { double o = v * 0.4 + f * 0.6; txtOrt.Text = o.ToString("F2"); txtHarf.Text = HH(o); txtHarf.ForeColor = o >= 60 ? Color.LimeGreen : Color.Red; } else { txtOrt.Text = ""; txtHarf.Text = ""; } }
        private void Kaydet(object? s, EventArgs e)
        {
            if (cmbOgr.SelectedIndex < 0 || cmbDers.SelectedIndex < 0 || !int.TryParse(txtVize.Text, out int v) || !int.TryParse(txtFinal.Text, out int f)) { MessageBox.Show("Tum alanlari doldurunuz!"); return; }
            if (v < 0 || v > 100 || f < 0 || f > 100) { MessageBox.Show("Not 0-100 arasi olmali!"); return; }
            try { using var cn = Db.Baglanti(); cn.Open(); int oid = ((CItem)cmbOgr.SelectedItem!).ID, did = ((CItem)cmbDers.SelectedItem!).ID; using var cmd = new SqlCommand("IF EXISTS(SELECT 1 FROM Notlar WHERE OgrenciID=@o AND DersID=@d)UPDATE Notlar SET VizeNotu=@v,FinalNotu=@f,HarfNotu=@h WHERE OgrenciID=@o AND DersID=@d ELSE INSERT INTO Notlar(OgrenciID,DersID,VizeNotu,FinalNotu,HarfNotu)VALUES(@o,@d,@v,@f,@h)", cn); cmd.Parameters.AddWithValue("@o", oid); cmd.Parameters.AddWithValue("@d", did); cmd.Parameters.AddWithValue("@v", v); cmd.Parameters.AddWithValue("@f", f); cmd.Parameters.AddWithValue("@h", txtHarf.Text); cmd.ExecuteNonQuery(); MessageBox.Show($"Not kaydedildi!\nOrtalama: {txtOrt.Text}\nHarf: {txtHarf.Text}", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }

    public class OgretmenListesiEkrani : Form
    {
        private DataGridView dgv;
        public OgretmenListesiEkrani()
        {
            Text = "Ogretmen Listesi"; Size = new Size(750, 520); S.Apply(this);
            var t = S.Lbl("Ogretmen Listesi", S.H1); t.ForeColor = S.Accent; t.Location = new Point(260, 10); Controls.Add(t);
            dgv = S.Dgv(); dgv.Location = new Point(35, 55); dgv.Size = new Size(670, 310); Controls.Add(dgv);
            var eb = S.Btn("Ogretmen Ekle", S.BtnGreen, 190, 40); eb.Location = new Point(40, 380); eb.Click += (s, e) => { new OgretmenEkleForm().ShowDialog(); Yukle(); }; Controls.Add(eb);
            var gb = S.Btn("Guncelle", S.BtnBlue, 190, 40); gb.Location = new Point(260, 380); gb.Click += (s, e) => { if (dgv.SelectedRows.Count > 0) { new OgretmenEkleForm(Convert.ToInt32(dgv.SelectedRows[0].Cells["OgretmenID"].Value)).ShowDialog(); Yukle(); } }; Controls.Add(gb);
            var sb = S.Btn("Sil", S.BtnRed, 190, 40); sb.Location = new Point(480, 380); sb.Click += (s, e) => { if (dgv.SelectedRows.Count == 0) return; if (MessageBox.Show("Silmek istediginize emin misiniz?", "Onay", MessageBoxButtons.YesNo) == DialogResult.Yes) { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("DELETE FROM Ogretmenler WHERE OgretmenID=@id", cn); cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgv.SelectedRows[0].Cells["OgretmenID"].Value)); cmd.ExecuteNonQuery(); Yukle(); } catch (Exception ex) { MessageBox.Show($"Silme hatasi: {ex.Message}"); } } }; Controls.Add(sb); Yukle();
        }
        private void Yukle() { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("SELECT o.OgretmenID,o.Unvan,o.Ad,o.Soyad,b.BolumAdi AS[Bolum],o.Telefon,o.Email FROM Ogretmenler o INNER JOIN Bolumler b ON o.BolumID=b.BolumID ORDER BY o.Soyad", cn); var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt; if (dgv.Columns.Contains("OgretmenID")) dgv.Columns["OgretmenID"].Visible = false; } catch (Exception ex) { MessageBox.Show(ex.Message); } }
    }

    public class OgretmenEkleForm : Form
    {
        private TextBox txtAd, txtSoyad, txtUnvan, txtTel, txtEmail; private ComboBox cmbBol; private int? id;
        public OgretmenEkleForm(int? ogrtId = null)
        {
            id = ogrtId; Text = id.HasValue ? "Ogretmen Guncelle" : "Ogretmen Ekle"; Size = new Size(450, 420); S.Apply(this);
            var t = S.Lbl(Text, S.H2); t.ForeColor = S.Accent; t.Location = new Point(110, 10); Controls.Add(t);
            var p = S.Pnl(390, 270); p.Location = new Point(25, 45);
            int lx = 15, tx = 115, y = 10, g = 45;
            p.Controls.Add(S.FLbl("Ad:", lx, y)); txtAd = S.Tb(230); txtAd.Location = new Point(tx, y); p.Controls.Add(txtAd);
            y += g; p.Controls.Add(S.FLbl("Soyad:", lx, y)); txtSoyad = S.Tb(230); txtSoyad.Location = new Point(tx, y); p.Controls.Add(txtSoyad);
            y += g; p.Controls.Add(S.FLbl("Unvan:", lx, y)); txtUnvan = S.Tb(230); txtUnvan.Location = new Point(tx, y); p.Controls.Add(txtUnvan);
            y += g; p.Controls.Add(S.FLbl("Bolum:", lx, y)); cmbBol = S.Cmb(230); cmbBol.Location = new Point(tx, y); p.Controls.Add(cmbBol);
            y += g; p.Controls.Add(S.FLbl("Telefon:", lx, y)); txtTel = S.Tb(230); txtTel.Location = new Point(tx, y); p.Controls.Add(txtTel);
            y += g; p.Controls.Add(S.FLbl("Email:", lx, y)); txtEmail = S.Tb(230); txtEmail.Location = new Point(tx, y); p.Controls.Add(txtEmail);
            Controls.Add(p);
            var kb = S.Btn("Kaydet", S.BtnGreen, 150, 38); kb.Location = new Point(45, 330); kb.Click += Kaydet; Controls.Add(kb);
            var ib = S.Btn("Iptal", S.BtnRed, 150, 38); ib.Location = new Point(240, 330); ib.Click += (s, e) => Close(); Controls.Add(ib);
            BolYukle(); if (id.HasValue) Yukle();
        }
        private void BolYukle() { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("SELECT BolumID,BolumAdi FROM Bolumler ORDER BY BolumAdi", cn); using var rd = cmd.ExecuteReader(); while (rd.Read()) cmbBol.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbBol.Items.Count > 0) cmbBol.SelectedIndex = 0; } catch { } }
        private void Yukle() { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("SELECT Ad,Soyad,Unvan,BolumID,Telefon,Email FROM Ogretmenler WHERE OgretmenID=@id", cn); cmd.Parameters.AddWithValue("@id", id!.Value); using var rd = cmd.ExecuteReader(); if (rd.Read()) { txtAd.Text = rd.GetString(0); txtSoyad.Text = rd.GetString(1); txtUnvan.Text = rd.IsDBNull(2) ? "" : rd.GetString(2); int bid = rd.GetInt32(3); for (int i = 0; i < cmbBol.Items.Count; i++) if (((CItem)cmbBol.Items[i]).ID == bid) { cmbBol.SelectedIndex = i; break; } txtTel.Text = rd.IsDBNull(4) ? "" : rd.GetString(4); txtEmail.Text = rd.IsDBNull(5) ? "" : rd.GetString(5); } } catch { } }
        private void Kaydet(object? s, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAd.Text) || string.IsNullOrWhiteSpace(txtSoyad.Text)) { MessageBox.Show("Ad ve Soyad zorunlu!"); return; }
            try
            {
                using var cn = Db.Baglanti(); cn.Open(); int bid = ((CItem)cmbBol.SelectedItem!).ID;
                if (id.HasValue) { using var cmd = new SqlCommand("UPDATE Ogretmenler SET Ad=@a,Soyad=@s,Unvan=@u,BolumID=@b,Telefon=@t,Email=@e WHERE OgretmenID=@id", cn); cmd.Parameters.AddWithValue("@a", txtAd.Text); cmd.Parameters.AddWithValue("@s", txtSoyad.Text); cmd.Parameters.AddWithValue("@u", (object?)txtUnvan.Text ?? DBNull.Value); cmd.Parameters.AddWithValue("@b", bid); cmd.Parameters.AddWithValue("@t", txtTel.Text); cmd.Parameters.AddWithValue("@e", txtEmail.Text); cmd.Parameters.AddWithValue("@id", id.Value); cmd.ExecuteNonQuery(); MessageBox.Show("Guncellendi!"); }
                else { using var cmd = new SqlCommand("INSERT INTO Ogretmenler(Ad,Soyad,Unvan,BolumID,Telefon,Email)VALUES(@a,@s,@u,@b,@t,@e)", cn); cmd.Parameters.AddWithValue("@a", txtAd.Text); cmd.Parameters.AddWithValue("@s", txtSoyad.Text); cmd.Parameters.AddWithValue("@u", (object?)txtUnvan.Text ?? DBNull.Value); cmd.Parameters.AddWithValue("@b", bid); cmd.Parameters.AddWithValue("@t", txtTel.Text); cmd.Parameters.AddWithValue("@e", txtEmail.Text); cmd.ExecuteNonQuery(); MessageBox.Show("Eklendi!"); }
                Close();
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }
}
