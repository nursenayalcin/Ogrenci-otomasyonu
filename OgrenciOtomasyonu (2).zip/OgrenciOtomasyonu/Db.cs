using System;
using Microsoft.Data.SqlClient;

namespace OgrenciOtomasyonu.Utils
{
    public static class Db
    {
        private static readonly string _cs =
            @"Server=(localdb)\MSSQLLocalDB;Database=OgrenciOtomasyonDB;Trusted_Connection=True;TrustServerCertificate=True;";

        public static string ConnectionString => _cs;
        public static SqlConnection Baglanti() => new SqlConnection(_cs);

        public static bool Test()
        {
            try { using var c = Baglanti(); c.Open(); return true; }
            catch { return false; }
        }

        public static string HataMesaji(Exception ex) =>
            $"Veritabani baglanti hatasi!\n\n1. SQL Server calistigindan emin olun\n" +
            $"2. OgrenciOtomasyonDB olusturulmus olmali\n3. Connection string kontrol edin\n\nHata: {ex.Message}";
    }
}
