using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace OgrenciOtomasyonu.Utils
{
    public static class Db
    {
        private static readonly string _cs = @"Server=(localdb)\MSSQLLocalDB;Database=OgrenciOtomasyonDB;Trusted_Connection=True;TrustServerCertificate=True;";
        public static SqlConnection Baglanti() => new SqlConnection(_cs);
        public static bool Test() { try { using var c = Baglanti(); c.Open(); return true; } catch { return false; } }
        public static string Hata(Exception ex) => $"Veritabani baglanti hatasi!\n1. SQL Server calisiyor mu?\n2. OgrenciOtomasyonDB olusturuldu mu?\n\nHata: {ex.Message}";
    }

    // Sayfa navigasyonu: üst üste açılma yerine mevcut formu gizle, yeniyi göster, kapanınca geri gel
    public static class Nav
    {
        public static void Git(Form mevcut, Form hedef)
        {
            mevcut.Hide();
            hedef.FormClosed += (s, e) => mevcut.Show();
            hedef.Show();
        }
        public static void GitDialog(Form hedef)
        {
            hedef.ShowDialog();
        }
    }

    public static class S
    {
        public static Color BG=Color.FromArgb(30,30,30), Panel=Color.FromArgb(45,45,45), Accent=Color.FromArgb(70,130,180);
        public static Color Txt=Color.White, Dim=Color.FromArgb(150,150,150);
        public static Color BtnDef=Color.FromArgb(70,70,70), BtnRed=Color.FromArgb(180,50,50), BtnGreen=Color.FromArgb(50,150,80);
        public static Color BtnBlue=Color.FromArgb(50,100,180), BtnOrange=Color.FromArgb(200,130,40);
        public static Font H1=new("Segoe UI",18,FontStyle.Bold), H2=new("Segoe UI",14,FontStyle.Bold);
        public static Font Norm=new("Segoe UI",11), Small=new("Segoe UI",9);
        public static Font BtnF=new("Segoe UI",11,FontStyle.Bold), FldF=new("Segoe UI",11,FontStyle.Bold);

        public static void Apply(Form f){f.BackColor=BG;f.ForeColor=Txt;f.Font=Norm;f.StartPosition=FormStartPosition.CenterScreen;f.FormBorderStyle=FormBorderStyle.FixedSingle;f.MaximizeBox=false;}
        public static Button Btn(string t,Color c,int w=200,int h=40){var b=new Button{Text=t,Size=new Size(w,h),FlatStyle=FlatStyle.Flat,BackColor=c,ForeColor=Txt,Font=BtnF,Cursor=Cursors.Hand};b.FlatAppearance.BorderColor=Color.FromArgb(80,80,80);b.FlatAppearance.MouseOverBackColor=Color.FromArgb(Math.Min(c.R+30,255),Math.Min(c.G+30,255),Math.Min(c.B+30,255));return b;}
        public static TextBox Tb(int w=250)=>new(){Size=new Size(w,30),BackColor=Color.FromArgb(60,60,60),ForeColor=Txt,Font=Norm,BorderStyle=BorderStyle.FixedSingle};
        public static Label Lbl(string t,Font? f=null)=>new(){Text=t,ForeColor=Txt,Font=f??Norm,AutoSize=true};
        public static Label FLbl(string t,int x,int y)=>new(){Text=t,Font=FldF,ForeColor=Txt,AutoSize=true,Location=new Point(x,y+3)};
        public static Label Desc(string t,int x,int y)=>new(){Text=t,ForeColor=Dim,Font=Small,AutoSize=true,Location=new Point(x,y)};
        public static ComboBox Cmb(int w=250)=>new(){Size=new Size(w,30),BackColor=Color.FromArgb(60,60,60),ForeColor=Txt,Font=Norm,DropDownStyle=ComboBoxStyle.DropDownList,FlatStyle=FlatStyle.Flat};
        public static Panel Pnl(int w,int h)=>new(){Size=new Size(w,h),BackColor=Panel};
        public static DataGridView Dgv(){var d=new DataGridView{BackgroundColor=Panel,ForeColor=Txt,GridColor=Color.FromArgb(70,70,70),BorderStyle=BorderStyle.None,CellBorderStyle=DataGridViewCellBorderStyle.SingleHorizontal,ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.Single,EnableHeadersVisualStyles=false,SelectionMode=DataGridViewSelectionMode.FullRowSelect,ReadOnly=true,AllowUserToAddRows=false,AllowUserToDeleteRows=false,AllowUserToResizeRows=false,RowHeadersVisible=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,Font=Norm};d.DefaultCellStyle.BackColor=Color.FromArgb(50,50,50);d.DefaultCellStyle.ForeColor=Txt;d.DefaultCellStyle.SelectionBackColor=Accent;d.DefaultCellStyle.SelectionForeColor=Txt;d.DefaultCellStyle.Padding=new Padding(5);d.AlternatingRowsDefaultCellStyle.BackColor=Color.FromArgb(40,40,40);d.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(60,60,60);d.ColumnHeadersDefaultCellStyle.ForeColor=Color.FromArgb(180,210,240);d.ColumnHeadersDefaultCellStyle.Font=new Font("Segoe UI",11,FontStyle.Bold);d.ColumnHeadersDefaultCellStyle.Padding=new Padding(5);d.ColumnHeadersHeight=40;return d;}
        public static string HarfNotu(double o)=>o>=90?"AA":o>=85?"BA":o>=80?"BB":o>=75?"CB":o>=70?"CC":o>=65?"DC":o>=60?"DD":o>=50?"FD":"FF";
    }

    public class CItem{public int ID{get;set;}public string Ad{get;set;}="";public override string ToString()=>Ad;}
}
