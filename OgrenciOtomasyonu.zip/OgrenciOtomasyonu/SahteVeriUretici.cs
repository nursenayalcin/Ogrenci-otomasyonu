using System;
using System.Linq;
using Microsoft.Data.SqlClient;

namespace OgrenciOtomasyonu.Utils
{
    public class SahteVeriUretici
    {
        private readonly Random _r;
        private readonly string[] _erkek = { "Ahmet", "Mehmet", "Mustafa", "Ali", "Hasan", "Murat", "Emre", "Burak", "Kaan", "Enes", "Yusuf", "Serkan", "Cem", "Deniz", "Berk", "Arda", "Furkan", "Eren", "Onur", "Volkan", "Selim" };
        private readonly string[] _kadin = { "Ayse", "Fatma", "Elif", "Zeynep", "Hatice", "Merve", "Selin", "Nursena", "Sude", "Aylin", "Derya", "Gamze", "Ceren", "Ebru", "Esra", "Irem", "Beyza", "Damla", "Tugba", "Yasemin", "Cansu", "Dilara" };
        private readonly string[] _soyad = { "Yilmaz", "Kaya", "Demir", "Celik", "Sahin", "Yildiz", "Ozturk", "Arslan", "Dogan", "Kilic", "Cetin", "Korkmaz", "Erdogan", "Aydin", "Koc", "Gunes", "Kurt", "Aksoy", "Ozdemir", "Guler", "Kaplan", "Acar", "Turan", "Bulut", "Polat", "Sen", "Uysal", "Ates", "Coskun", "Tas", "Aktas", "Sari", "Kara", "Uzun", "Keskin", "Bozkurt", "Erdem" };
        private readonly string[] _unvan = { "Prof. Dr.", "Doc. Dr.", "Dr. Ogr. Uyesi", "Ogr. Gor.", "Ogr. Gor.", "Ars. Gor." };

        public SahteVeriUretici(int? seed = null) { _r = seed.HasValue ? new Random(seed.Value) : new Random(); }
        public string AdUret() { var h = _r.Next(2) == 0 ? _erkek : _kadin; return h[_r.Next(h.Length)]; }
        public string SoyadUret() => _soyad[_r.Next(_soyad.Length)];
        public string UnvanUret() => _unvan[_r.Next(_unvan.Length)];
        public string TelefonUret() => $"05{_r.Next(30, 60)}-{_r.Next(100, 999)}-{_r.Next(1000, 9999)}";
        public string EmailUret(string ad, string soyad, string domain = "stu.kmyo.edu.tr") => $"{ad.ToLower()}.{soyad.ToLower()}@{domain}";
        public string OgrNoUret(string bolKod, int sira, int yil = 2024) => $"{yil}{bolKod}{sira:D3}";
        public int NotUret(int ort = 65, int std = 15)
        {
            double u1 = 1.0 - _r.NextDouble(), u2 = 1.0 - _r.NextDouble();
            int n = (int)(ort + Math.Sqrt(-2 * Math.Log(u1)) * Math.Sin(2 * Math.PI * u2) * std);
            return Math.Max(0, Math.Min(100, n));
        }
        public string HarfNotu(double o) => o >= 90 ? "AA" : o >= 85 ? "BA" : o >= 80 ? "BB" : o >= 75 ? "CB" : o >= 70 ? "CC" : o >= 65 ? "DC" : o >= 60 ? "DD" : o >= 50 ? "FD" : "FF";

        public int OgrenciEkle(int adet, int bolumId, int sinif, string bolKod)
        {
            int ek = 0;
            using var c = Db.Baglanti(); c.Open();
            int son = 0;
            using (var cmd = new SqlCommand("SELECT ISNULL(MAX(CAST(RIGHT(OgrenciNo,3)AS INT)),0) FROM Ogrenciler WHERE OgrenciNo LIKE @p", c))
            { cmd.Parameters.AddWithValue("@p", $"%{bolKod}%"); son = (int)cmd.ExecuteScalar(); }
            for (int i = 1; i <= adet; i++)
            {
                string ad = AdUret(), soyad = SoyadUret();
                using var cmd = new SqlCommand("INSERT INTO Ogrenciler(OgrenciNo,Ad,Soyad,BolumID,Sinif,Email,Telefon)VALUES(@no,@ad,@soy,@b,@s,@e,@t)", c);
                cmd.Parameters.AddWithValue("@no", OgrNoUret(bolKod, son + i));
                cmd.Parameters.AddWithValue("@ad", ad); cmd.Parameters.AddWithValue("@soy", soyad);
                cmd.Parameters.AddWithValue("@b", bolumId); cmd.Parameters.AddWithValue("@s", sinif);
                cmd.Parameters.AddWithValue("@e", EmailUret(ad, soyad)); cmd.Parameters.AddWithValue("@t", TelefonUret());
                try { cmd.ExecuteNonQuery(); ek++; } catch { }
            }
            return ek;
        }
    }
}
