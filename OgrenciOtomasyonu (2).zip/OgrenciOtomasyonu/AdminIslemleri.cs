using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class BolumEkleEkrani : Form
    {
        private TextBox txtAd, txtKod; private DataGridView dgv;
        public BolumEkleEkrani()
        {
            Text = "Bolum Yonetimi"; Size = new Size(550, 480); S.Apply(this);
            var t = S.Lbl("Bolum Yonetimi", S.H2); t.ForeColor = S.Accent; t.Location = new Point(170, 10); Controls.Add(t);
            var p = S.Pnl(470, 100); p.Location = new Point(35, 45);
            p.Controls.Add(S.FLbl("Bolum Adi:", 15, 15)); txtAd = S.Tb(250); txtAd.Location = new Point(130, 15); p.Controls.Add(txtAd);
            p.Controls.Add(S.FLbl("Bolum Kodu:", 15, 55)); txtKod = S.Tb(80); txtKod.Location = new Point(130, 55); p.Controls.Add(txtKod);
            var eb = S.Btn("Ekle", S.BtnGreen, 100, 35); eb.Location = new Point(350, 55); eb.Click += Ekle; p.Controls.Add(eb);
            Controls.Add(p);
            dgv = S.Dgv(); dgv.Location = new Point(35, 160); dgv.Size = new Size(470, 230); Controls.Add(dgv);
            var sb = S.Btn("Bolum Sil", S.BtnRed, 130, 35); sb.Location = new Point(375, 400);
            sb.Click += (s, e) => { if (dgv.SelectedRows.Count == 0) return; if (MessageBox.Show("Silmek istediginize emin misiniz?", "Onay", MessageBoxButtons.YesNo) == DialogResult.Yes) { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("DELETE FROM Bolumler WHERE BolumID=@id", cn); cmd.Parameters.AddWithValue("@id", Convert.ToInt32(dgv.SelectedRows[0].Cells["BolumID"].Value)); cmd.ExecuteNonQuery(); Yukle(); } catch (Exception ex) { MessageBox.Show($"Bu bolume bagli kayitlar olabilir: {ex.Message}"); } } }; Controls.Add(sb);
            Yukle();
        }
        private void Yukle() { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("SELECT BolumID,BolumKodu AS[Kod],BolumAdi AS[Bolum Adi]FROM Bolumler ORDER BY BolumAdi", cn); var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt; if (dgv.Columns.Contains("BolumID")) dgv.Columns["BolumID"].Visible = false; } catch { } }
        private void Ekle(object? s, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtAd.Text) || string.IsNullOrWhiteSpace(txtKod.Text)) { MessageBox.Show("Alanlari doldurunuz!"); return; }
            try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("INSERT INTO Bolumler(BolumAdi,BolumKodu)VALUES(@a,@k)", cn); cmd.Parameters.AddWithValue("@a", txtAd.Text); cmd.Parameters.AddWithValue("@k", txtKod.Text.ToUpper()); cmd.ExecuteNonQuery(); txtAd.Clear(); txtKod.Clear(); Yukle(); MessageBox.Show("Bolum eklendi!"); } catch (SqlException ex) when (ex.Number == 2627) { MessageBox.Show("Bu bolum zaten var!"); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }

    public class KullaniciOlusturEkrani : Form
    {
        private TextBox txtUser, txtPass; private ComboBox cmbRol, cmbIlgili;
        public KullaniciOlusturEkrani()
        {
            Text = "Kullanici Olustur"; Size = new Size(450, 350); S.Apply(this);
            var t = S.Lbl("Kullanici Olustur", S.H2); t.ForeColor = S.Accent; t.Location = new Point(120, 10); Controls.Add(t);
            var p = S.Pnl(390, 210); p.Location = new Point(25, 45);
            int lx = 15, tx = 140, y = 15, g = 48;
            p.Controls.Add(S.FLbl("Kullanici Adi:", lx, y)); txtUser = S.Tb(210); txtUser.Location = new Point(tx, y); p.Controls.Add(txtUser);
            y += g; p.Controls.Add(S.FLbl("Sifre:", lx, y)); txtPass = S.Tb(210); txtPass.Location = new Point(tx, y); p.Controls.Add(txtPass);
            y += g; p.Controls.Add(S.FLbl("Rol:", lx, y)); cmbRol = S.Cmb(210); cmbRol.Location = new Point(tx, y);
            cmbRol.Items.AddRange(new[] { "Ogrenci", "Akademisyen", "Admin" }); cmbRol.SelectedIndex = 0;
            cmbRol.SelectedIndexChanged += (s, e) => IlgiliYukle(); p.Controls.Add(cmbRol);
            y += g; p.Controls.Add(S.FLbl("Ilgili Kisi:", lx, y)); cmbIlgili = S.Cmb(210); cmbIlgili.Location = new Point(tx, y); p.Controls.Add(cmbIlgili);
            Controls.Add(p);
            var kb = S.Btn("Olustur", S.BtnGreen, 150, 38); kb.Location = new Point(60, 270); kb.Click += Olustur; Controls.Add(kb);
            var ib = S.Btn("Iptal", S.BtnRed, 150, 38); ib.Location = new Point(230, 270); ib.Click += (s, e) => Close(); Controls.Add(ib);
            IlgiliYukle();
        }
        private void IlgiliYukle()
        {
            cmbIlgili.Items.Clear(); string rol = cmbRol.SelectedItem?.ToString() ?? "";
            if (rol == "Admin") { cmbIlgili.Items.Add(new CItem { ID = 0, Ad = "- Yok -" }); cmbIlgili.SelectedIndex = 0; return; }
            try { using var cn = Db.Baglanti(); cn.Open(); string sql = rol == "Ogrenci" ? "SELECT OgrenciID,OgrenciNo+' - '+Ad+' '+Soyad FROM Ogrenciler WHERE Aktif=1 ORDER BY Soyad" : "SELECT OgretmenID,ISNULL(Unvan+' ','')+Ad+' '+Soyad FROM Ogretmenler ORDER BY Soyad"; using var cmd = new SqlCommand(sql, cn); using var rd = cmd.ExecuteReader(); while (rd.Read()) cmbIlgili.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbIlgili.Items.Count > 0) cmbIlgili.SelectedIndex = 0; } catch { }
        }
        private void Olustur(object? s, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUser.Text) || string.IsNullOrWhiteSpace(txtPass.Text)) { MessageBox.Show("Kullanici adi ve sifre zorunlu!"); return; }
            try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("INSERT INTO Kullanicilar(KullaniciAdi,Sifre,Rol,IlgiliID)VALUES(@u,@p,@r,@i)", cn); cmd.Parameters.AddWithValue("@u", txtUser.Text); cmd.Parameters.AddWithValue("@p", txtPass.Text); cmd.Parameters.AddWithValue("@r", cmbRol.SelectedItem!.ToString()!); int ilgili = cmbIlgili.SelectedIndex >= 0 ? ((CItem)cmbIlgili.SelectedItem!).ID : 0; cmd.Parameters.AddWithValue("@i", ilgili == 0 ? (object)DBNull.Value : ilgili); cmd.ExecuteNonQuery(); MessageBox.Show("Kullanici olusturuldu!"); Close(); } catch (SqlException ex) when (ex.Number == 2627) { MessageBox.Show("Bu kullanici adi zaten var!"); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }

    public class DevamsizlikEkrani : Form
    {
        private ComboBox cmbOgr, cmbDers, cmbDurum; private DateTimePicker dtpTarih; private TextBox txtAciklama; private DataGridView dgv;
        public DevamsizlikEkrani()
        {
            Text = "Devamsizlik Islemleri"; Size = new Size(800, 580); S.Apply(this);
            var t = S.Lbl("Devamsizlik Islemleri", S.H2); t.ForeColor = S.Accent; t.Location = new Point(270, 8); Controls.Add(t);
            var p = S.Pnl(720, 130); p.Location = new Point(35, 40);
            p.Controls.Add(S.FLbl("Ogrenci:", 10, 10)); cmbOgr = S.Cmb(250); cmbOgr.Location = new Point(100, 10); p.Controls.Add(cmbOgr);
            p.Controls.Add(S.FLbl("Ders:", 380, 10)); cmbDers = S.Cmb(200); cmbDers.Location = new Point(430, 10); p.Controls.Add(cmbDers);
            p.Controls.Add(S.FLbl("Tarih:", 10, 50)); dtpTarih = new DateTimePicker { Location = new Point(100, 50), Size = new Size(150, 30), Format = DateTimePickerFormat.Short }; p.Controls.Add(dtpTarih);
            p.Controls.Add(S.FLbl("Durum:", 280, 50)); cmbDurum = S.Cmb(120); cmbDurum.Location = new Point(350, 50); cmbDurum.Items.AddRange(new[] { "Geldi", "Gelmedi", "Izinli" }); cmbDurum.SelectedIndex = 0; p.Controls.Add(cmbDurum);
            p.Controls.Add(S.FLbl("Aciklama:", 500, 50)); txtAciklama = S.Tb(170); txtAciklama.Location = new Point(580, 50); p.Controls.Add(txtAciklama);
            var eb = S.Btn("Kaydet", S.BtnGreen, 120, 35); eb.Location = new Point(300, 90); eb.Click += Kaydet; p.Controls.Add(eb);
            Controls.Add(p);
            dgv = S.Dgv(); dgv.Location = new Point(35, 185); dgv.Size = new Size(720, 330); Controls.Add(dgv);
            var gb = S.Btn("Geri", S.BtnDef, 120, 35); gb.Location = new Point(340, 525); gb.Click += (s, e) => Close(); Controls.Add(gb);
            CmbYukle(); Yukle();
        }
        private void CmbYukle() { try { using var cn = Db.Baglanti(); cn.Open(); using (var cmd = new SqlCommand("SELECT OgrenciID,OgrenciNo+' - '+Ad+' '+Soyad FROM Ogrenciler WHERE Aktif=1 ORDER BY Soyad", cn)) using (var rd = cmd.ExecuteReader()) while (rd.Read()) cmbOgr.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbOgr.Items.Count > 0) cmbOgr.SelectedIndex = 0; using (var cmd = new SqlCommand("SELECT DersID,DersKodu+' - '+DersAdi FROM Dersler ORDER BY DersKodu", cn)) using (var rd = cmd.ExecuteReader()) while (rd.Read()) cmbDers.Items.Add(new CItem { ID = rd.GetInt32(0), Ad = rd.GetString(1) }); if (cmbDers.Items.Count > 0) cmbDers.SelectedIndex = 0; } catch { } }
        private void Yukle() { try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand(@"SELECT dv.DevamsizlikID,o.Ad+' '+o.Soyad AS[Ogrenci],d.DersKodu AS[Ders],dv.Tarih,dv.Durum,dv.Aciklama FROM Devamsizlik dv INNER JOIN Ogrenciler o ON dv.OgrenciID=o.OgrenciID INNER JOIN Dersler d ON dv.DersID=d.DersID ORDER BY dv.Tarih DESC", cn); var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt; if (dgv.Columns.Contains("DevamsizlikID")) dgv.Columns["DevamsizlikID"].Visible = false; } catch { } }
        private void Kaydet(object? s, EventArgs e)
        {
            if (cmbOgr.SelectedIndex < 0 || cmbDers.SelectedIndex < 0) { MessageBox.Show("Ogrenci ve ders seciniz!"); return; }
            try { using var cn = Db.Baglanti(); cn.Open(); using var cmd = new SqlCommand("IF EXISTS(SELECT 1 FROM Devamsizlik WHERE OgrenciID=@o AND DersID=@d AND Tarih=@t)UPDATE Devamsizlik SET Durum=@du,Aciklama=@a WHERE OgrenciID=@o AND DersID=@d AND Tarih=@t ELSE INSERT INTO Devamsizlik(OgrenciID,DersID,Tarih,Durum,Aciklama)VALUES(@o,@d,@t,@du,@a)", cn); cmd.Parameters.AddWithValue("@o", ((CItem)cmbOgr.SelectedItem!).ID); cmd.Parameters.AddWithValue("@d", ((CItem)cmbDers.SelectedItem!).ID); cmd.Parameters.AddWithValue("@t", dtpTarih.Value.Date); cmd.Parameters.AddWithValue("@du", cmbDurum.SelectedItem!.ToString()!); cmd.Parameters.AddWithValue("@a", string.IsNullOrEmpty(txtAciklama.Text) ? (object)DBNull.Value : txtAciklama.Text); cmd.ExecuteNonQuery(); Yukle(); MessageBox.Show("Devamsizlik kaydedildi!"); } catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }

    public class RaporEkrani : Form
    {
        public RaporEkrani()
        {
            Text = "Rapor Goruntule"; Size = new Size(750, 550); S.Apply(this);
            var t = S.Lbl("Raporlar", S.H1); t.ForeColor = S.Accent; t.Location = new Point(310, 8); Controls.Add(t);
            var dgv = S.Dgv(); dgv.Location = new Point(30, 50); dgv.Size = new Size(680, 200); Controls.Add(dgv);
            var lbl1 = S.Lbl("Bolum Bazinda Ogrenci Sayilari", S.FldF); lbl1.ForeColor = S.Accent; lbl1.Location = new Point(220, 260); Controls.Add(lbl1);
            var dgv2 = S.Dgv(); dgv2.Location = new Point(30, 290); dgv2.Size = new Size(680, 180); Controls.Add(dgv2);
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using (var cmd = new SqlCommand(@"SELECT 'Toplam Ogrenci' AS Bilgi,(SELECT COUNT(*) FROM Ogrenciler WHERE Aktif=1)AS Sayi UNION ALL SELECT 'Toplam Ogretmen',(SELECT COUNT(*) FROM Ogretmenler) UNION ALL SELECT 'Toplam Ders',(SELECT COUNT(*) FROM Dersler) UNION ALL SELECT 'Toplam Bolum',(SELECT COUNT(*) FROM Bolumler) UNION ALL SELECT 'Toplam Not Kaydi',(SELECT COUNT(*) FROM Notlar) UNION ALL SELECT 'Toplam Devamsizlik Kaydi',(SELECT COUNT(*) FROM Devamsizlik) UNION ALL SELECT 'Aktif Kullanici Sayisi',(SELECT COUNT(*) FROM Kullanicilar WHERE Aktif=1) UNION ALL SELECT 'Genel Not Ortalamasi',CAST(ISNULL(ROUND(AVG(Ortalama),2),0)AS INT) FROM Notlar WHERE Ortalama IS NOT NULL", cn))
                { var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt; }
                using (var cmd = new SqlCommand(@"SELECT b.BolumAdi AS[Bolum],COUNT(o.OgrenciID)AS[Ogrenci Sayisi],(SELECT COUNT(*) FROM Dersler d WHERE d.BolumID=b.BolumID)AS[Ders Sayisi],(SELECT COUNT(*) FROM Ogretmenler t WHERE t.BolumID=b.BolumID)AS[Ogretmen Sayisi] FROM Bolumler b LEFT JOIN Ogrenciler o ON b.BolumID=o.BolumID AND o.Aktif=1 GROUP BY b.BolumID,b.BolumAdi ORDER BY b.BolumAdi", cn))
                { var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv2.DataSource = dt; }
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            var gb = S.Btn("Geri", S.BtnDef, 120, 35); gb.Location = new Point(310, 490); gb.Click += (s, e) => Close(); Controls.Add(gb);
        }
    }
}
