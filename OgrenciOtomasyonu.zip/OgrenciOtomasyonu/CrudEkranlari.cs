using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class DersYonetimiEkrani : Form
    {
        private TextBox txtAd,txtKod,txtKredi;private ComboBox cmbOgrt,cmbBol;private DataGridView dgv;
        public DersYonetimiEkrani(){Text="Ders Yonetimi";Size=new Size(750,620);S.Apply(this);var t=S.Lbl("Ders Yonetimi",S.H1);t.ForeColor=S.Accent;t.Location=new Point(280,8);Controls.Add(t);var p=S.Pnl(660,220);p.Location=new Point(40,45);int lx=25,tx=145,y=15,g=40;p.Controls.Add(S.FLbl("Ders Adi:",lx,y));txtAd=S.Tb(300);txtAd.Location=new Point(tx,y);p.Controls.Add(txtAd);y+=g;p.Controls.Add(S.FLbl("Ders Kodu:",lx,y));txtKod=S.Tb(120);txtKod.Location=new Point(tx,y);p.Controls.Add(txtKod);y+=g;p.Controls.Add(S.FLbl("Kredi:",lx,y));txtKredi=S.Tb(60);txtKredi.Location=new Point(tx,y);p.Controls.Add(txtKredi);y+=g;p.Controls.Add(S.FLbl("Ogretmen:",lx,y));cmbOgrt=S.Cmb(300);cmbOgrt.Location=new Point(tx,y);p.Controls.Add(cmbOgrt);y+=g;p.Controls.Add(S.FLbl("Bolum:",lx,y));cmbBol=S.Cmb(300);cmbBol.Location=new Point(tx,y);p.Controls.Add(cmbBol);var eb=S.Btn("Ders Ekle",S.BtnBlue,130,36);eb.Location=new Point(500,y);eb.Click+=Ekle;p.Controls.Add(eb);Controls.Add(p);dgv=S.Dgv();dgv.Location=new Point(40,280);dgv.Size=new Size(660,230);Controls.Add(dgv);var sb=S.Btn("Ders Sil",S.BtnRed,140,35);sb.Location=new Point(430,520);sb.Click+=(s,e)=>{if(dgv.SelectedRows.Count==0)return;if(MessageBox.Show("Silmek istediginize emin misiniz?","Onay",MessageBoxButtons.YesNo)==DialogResult.Yes){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("DELETE FROM Dersler WHERE DersID=@id",cn);cmd.Parameters.AddWithValue("@id",Convert.ToInt32(dgv.SelectedRows[0].Cells["DersID"].Value));cmd.ExecuteNonQuery();Yukle();}catch(Exception ex){MessageBox.Show(ex.Message);}}};Controls.Add(sb);var geri=S.Btn("Geri",S.BtnDef,120,35);geri.Location=new Point(580,520);geri.Click+=(s,e)=>Close();Controls.Add(geri);CY();Yukle();}
        void CY(){try{using var cn=Db.Baglanti();cn.Open();using(var cmd=new SqlCommand("SELECT OgretmenID,ISNULL(Unvan+' ','')+Ad+' '+Soyad FROM Ogretmenler ORDER BY Soyad",cn))using(var rd=cmd.ExecuteReader())while(rd.Read())cmbOgrt.Items.Add(new CItem{ID=rd.GetInt32(0),Ad=rd.GetString(1)});if(cmbOgrt.Items.Count>0)cmbOgrt.SelectedIndex=0;using(var cmd=new SqlCommand("SELECT BolumID,BolumAdi FROM Bolumler ORDER BY BolumAdi",cn))using(var rd=cmd.ExecuteReader())while(rd.Read())cmbBol.Items.Add(new CItem{ID=rd.GetInt32(0),Ad=rd.GetString(1)});if(cmbBol.Items.Count>0)cmbBol.SelectedIndex=0;}catch{}}
        void Yukle(){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT d.DersID,d.DersKodu AS[Ders Kodu],d.DersAdi AS[Ders Adi],d.Kredi,ISNULL(o.Ad+' '+o.Soyad,'-')AS[Ogretmen],b.BolumAdi AS[Bolum]FROM Dersler d LEFT JOIN Ogretmenler o ON d.OgretmenID=o.OgretmenID INNER JOIN Bolumler b ON d.BolumID=b.BolumID ORDER BY d.DersKodu",cn);var dt=new DataTable();dt.Load(cmd.ExecuteReader());dgv.DataSource=dt;if(dgv.Columns.Contains("DersID"))dgv.Columns["DersID"].Visible=false;}catch(Exception ex){MessageBox.Show(ex.Message);}}
        void Ekle(object? s,EventArgs e){if(string.IsNullOrWhiteSpace(txtAd.Text)||string.IsNullOrWhiteSpace(txtKod.Text)||!int.TryParse(txtKredi.Text,out int kr)){MessageBox.Show("Alanlari doldurunuz!");return;}try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("INSERT INTO Dersler(DersKodu,DersAdi,Kredi,OgretmenID,BolumID)VALUES(@k,@a,@kr,@o,@b)",cn);cmd.Parameters.AddWithValue("@k",txtKod.Text.ToUpper());cmd.Parameters.AddWithValue("@a",txtAd.Text);cmd.Parameters.AddWithValue("@kr",kr);cmd.Parameters.AddWithValue("@o",cmbOgrt.SelectedIndex>=0?((CItem)cmbOgrt.SelectedItem!).ID:(object)DBNull.Value);cmd.Parameters.AddWithValue("@b",((CItem)cmbBol.SelectedItem!).ID);cmd.ExecuteNonQuery();txtAd.Clear();txtKod.Clear();txtKredi.Clear();Yukle();MessageBox.Show("Ders eklendi!");}catch(SqlException ex)when(ex.Number==2627){MessageBox.Show("Bu ders kodu zaten var!");}catch(Exception ex){MessageBox.Show(ex.Message);}}
    }

    // ====================== NOT GIRISI - DERS LISTESI ======================
    // 1. adim: Ders listesi gosterilir. Admin ise tum dersler, ogretmen ise sadece kendi dersleri.
    public class NotGirisEkrani : Form
    {
        private DataGridView dgv; private int ogretmenId;
        public NotGirisEkrani(int ogretmenId=0)
        {
            this.ogretmenId=ogretmenId;
            Text="Not Girisi - Ders Sec"; Size=new Size(750,520); S.Apply(this);
            var t=S.Lbl("Ders Seciniz",S.H1); t.ForeColor=S.Accent; t.Location=new Point(260,10); Controls.Add(t);
            var bilgi=S.Lbl(ogretmenId>0 ? "Verdiginiz derslerden birini secin, ogrenciler listelenecek." : "Bir ders secin, ogrenciler listelenecek.",S.Small);
            bilgi.ForeColor=S.Dim; bilgi.Location=new Point(220,50); Controls.Add(bilgi);
            dgv=S.Dgv(); dgv.Location=new Point(35,80); dgv.Size=new Size(670,300); Controls.Add(dgv);
            dgv.CellDoubleClick+=(s,e)=>DersAc();

            var ab=S.Btn("Ders Ac / Not Gir",S.BtnGreen,220,45); ab.Location=new Point(130,400);
            ab.Click+=(s,e)=>DersAc(); Controls.Add(ab);
            var geri=S.Btn("Geri",S.BtnDef,220,45); geri.Location=new Point(400,400); geri.Click+=(s,e)=>Close(); Controls.Add(geri);
            Yukle();
        }
        void Yukle()
        {
            try{using var cn=Db.Baglanti(); cn.Open();
                string sql=ogretmenId>0
                    ? "SELECT d.DersID,d.DersKodu AS[Ders Kodu],d.DersAdi AS[Ders Adi],d.Kredi,d.Donem,(SELECT COUNT(*) FROM DersKayitlari dk WHERE dk.DersID=d.DersID) AS[Ogrenci Sayisi] FROM Dersler d WHERE d.OgretmenID=@tid ORDER BY d.DersKodu"
                    : "SELECT d.DersID,d.DersKodu AS[Ders Kodu],d.DersAdi AS[Ders Adi],d.Kredi,ISNULL(o.Ad+' '+o.Soyad,'-') AS[Ogretmen],(SELECT COUNT(*) FROM DersKayitlari dk WHERE dk.DersID=d.DersID) AS[Ogrenci Sayisi] FROM Dersler d LEFT JOIN Ogretmenler o ON d.OgretmenID=o.OgretmenID ORDER BY d.DersKodu";
                using var cmd=new SqlCommand(sql,cn);
                if(ogretmenId>0)cmd.Parameters.AddWithValue("@tid",ogretmenId);
                var dt=new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource=dt;
                if(dgv.Columns.Contains("DersID"))dgv.Columns["DersID"].Visible=false;
            }catch(Exception ex){MessageBox.Show(Db.Hata(ex));}
        }
        void DersAc()
        {
            if(dgv.SelectedRows.Count==0){MessageBox.Show("Lutfen bir ders secin.");return;}
            int dersId=Convert.ToInt32(dgv.SelectedRows[0].Cells["DersID"].Value);
            string dersAd=dgv.SelectedRows[0].Cells["Ders Adi"].Value.ToString()??"";
            Nav.Git(this,new DersNotGirisEkrani(dersId,dersAd));
        }
    }

    // ====================== 2. ADIM: Seçilen ders için öğrenci tablosu ======================
    public class DersNotGirisEkrani : Form
    {
        private int dersId; private string dersAd;
        private DataGridView dgv;
        private List<OgrNotSatir> satirlar=new();

        public DersNotGirisEkrani(int dersId,string dersAd)
        {
            this.dersId=dersId; this.dersAd=dersAd;
            Text=$"Not Girisi - {dersAd}"; Size=new Size(1000,640); S.Apply(this);

            var t=S.Lbl($"Ders: {dersAd}",S.H1); t.ForeColor=S.Accent; t.Location=new Point(30,10); Controls.Add(t);
            var bilgi=S.Lbl("Ogrenciler asagida listelendi. Notlari girin, durumu degistirin. Bittiginde 'Tumunu Kaydet' butonuna basin.",S.Small);
            bilgi.ForeColor=S.Dim; bilgi.Location=new Point(30,55); Controls.Add(bilgi);

            // Uyari mesaji: not girmediginiz ogrenciler olursa nasil islenecek
            var uyari=S.Lbl("NOT: Vize/Final girilmeyen ogrenciler icin durum 'Girmedi' olarak isaretlenirse notlari 0 kaydedilir.",S.Small);
            uyari.ForeColor=Color.Orange; uyari.Location=new Point(30,78); Controls.Add(uyari);

            dgv=new DataGridView{Location=new Point(30,110),Size=new Size(920,400),BackgroundColor=S.Panel,ForeColor=S.Txt,GridColor=Color.FromArgb(70,70,70),BorderStyle=BorderStyle.None,CellBorderStyle=DataGridViewCellBorderStyle.SingleHorizontal,ColumnHeadersBorderStyle=DataGridViewHeaderBorderStyle.Single,EnableHeadersVisualStyles=false,SelectionMode=DataGridViewSelectionMode.CellSelect,AllowUserToAddRows=false,AllowUserToDeleteRows=false,AllowUserToResizeRows=false,RowHeadersVisible=false,AutoSizeColumnsMode=DataGridViewAutoSizeColumnsMode.Fill,Font=S.Norm,RowTemplate=new DataGridViewRow{Height=42}};
            dgv.DefaultCellStyle.BackColor=Color.FromArgb(50,50,50); dgv.DefaultCellStyle.ForeColor=S.Txt;
            dgv.DefaultCellStyle.SelectionBackColor=S.Accent; dgv.DefaultCellStyle.SelectionForeColor=S.Txt; dgv.DefaultCellStyle.Padding=new Padding(8,8,8,8);
            dgv.AlternatingRowsDefaultCellStyle.BackColor=Color.FromArgb(40,40,40);
            dgv.ColumnHeadersDefaultCellStyle.BackColor=Color.FromArgb(60,60,60); dgv.ColumnHeadersDefaultCellStyle.ForeColor=Color.FromArgb(180,210,240);
            dgv.ColumnHeadersDefaultCellStyle.Font=new Font("Segoe UI",11,FontStyle.Bold); dgv.ColumnHeadersDefaultCellStyle.Padding=new Padding(8); dgv.ColumnHeadersHeight=45;

            // Sutunlar
            dgv.Columns.Add(new DataGridViewTextBoxColumn{Name="No",HeaderText="Ogrenci No",ReadOnly=true,FillWeight=18});
            dgv.Columns.Add(new DataGridViewTextBoxColumn{Name="Ad",HeaderText="Ad Soyad",ReadOnly=true,FillWeight=28});
            var cmbCol=new DataGridViewComboBoxColumn{Name="Durum",HeaderText="Durum",FillWeight=18,FlatStyle=FlatStyle.Flat};
            cmbCol.Items.AddRange("Girdi","Girmedi","Devamsiz"); dgv.Columns.Add(cmbCol);
            dgv.Columns.Add(new DataGridViewTextBoxColumn{Name="Vize",HeaderText="Vize (0-100)",FillWeight=15});
            dgv.Columns.Add(new DataGridViewTextBoxColumn{Name="Final",HeaderText="Final (0-100)",FillWeight=15});
            dgv.Columns.Add(new DataGridViewTextBoxColumn{Name="Harf",HeaderText="Harf",ReadOnly=true,FillWeight=8});
            dgv.CellValueChanged+=DgvCellChanged;
            dgv.CurrentCellDirtyStateChanged+=(s,e)=>{if(dgv.IsCurrentCellDirty)dgv.CommitEdit(DataGridViewDataErrorContexts.Commit);};
            dgv.DataError+=(s,e)=>{e.Cancel=true;};
            Controls.Add(dgv);

            var kb=S.Btn("Tumunu Kaydet",S.BtnGreen,220,50); kb.Location=new Point(250,530); kb.Click+=TumunuKaydet; Controls.Add(kb);
            var geri=S.Btn("Geri",S.BtnDef,220,50); geri.Location=new Point(520,530); geri.Click+=(s,e)=>Close(); Controls.Add(geri);

            OgrencileriYukle();
        }

        class OgrNotSatir { public int OgrenciID; public string No=""; public string AdSoyad=""; public string Durum="Girdi"; public string Vize=""; public string Final=""; }

        void OgrencileriYukle()
        {
            try{using var cn=Db.Baglanti(); cn.Open();
                // Kayitli notlari da cek - LEFT JOIN ile
                using var cmd=new SqlCommand(@"SELECT o.OgrenciID,o.OgrenciNo,o.Ad+' '+o.Soyad,n.VizeNotu,n.FinalNotu,n.HarfNotu FROM DersKayitlari dk INNER JOIN Ogrenciler o ON dk.OgrenciID=o.OgrenciID LEFT JOIN Notlar n ON n.OgrenciID=o.OgrenciID AND n.DersID=@d WHERE dk.DersID=@d AND o.Aktif=1 ORDER BY o.OgrenciNo",cn);
                cmd.Parameters.AddWithValue("@d",dersId);
                using var rd=cmd.ExecuteReader();
                while(rd.Read()){
                    var s=new OgrNotSatir{OgrenciID=rd.GetInt32(0),No=rd.GetString(1),AdSoyad=rd.GetString(2),Durum="Girdi"};
                    if(!rd.IsDBNull(3))s.Vize=Convert.ToInt32(rd.GetDecimal(3)).ToString();
                    if(!rd.IsDBNull(4))s.Final=Convert.ToInt32(rd.GetDecimal(4)).ToString();
                    satirlar.Add(s);
                }
            }catch(Exception ex){MessageBox.Show(Db.Hata(ex));return;}

            if(satirlar.Count==0){MessageBox.Show("Bu derse kayitli ogrenci bulunamadi.");return;}
            // Kayitli notlar varsa goster, yoksa bos
            foreach(var s in satirlar){
                int i=dgv.Rows.Add(s.No,s.AdSoyad,s.Durum,s.Vize,s.Final,"");
                HarfGuncelle(i);
            }
        }

        void DgvCellChanged(object? s,DataGridViewCellEventArgs e)
        {
            if(e.RowIndex<0)return;
            HarfGuncelle(e.RowIndex);
        }

        void HarfGuncelle(int row)
        {
            string v=dgv.Rows[row].Cells["Vize"].Value?.ToString()??"";
            string f=dgv.Rows[row].Cells["Final"].Value?.ToString()??"";
            if(int.TryParse(v,out int vi)&&int.TryParse(f,out int fi)){
                double ort=vi*0.4+fi*0.6;
                dgv.Rows[row].Cells["Harf"].Value=S.HarfNotu(ort);
            }else dgv.Rows[row].Cells["Harf"].Value="";
        }

        void TumunuKaydet(object? s,EventArgs e)
        {
            // Not girilmeyen ogrencileri bul
            var eksikler=new List<int>();
            for(int i=0;i<dgv.Rows.Count;i++){
                string v=dgv.Rows[i].Cells["Vize"].Value?.ToString()??"";
                string f=dgv.Rows[i].Cells["Final"].Value?.ToString()??"";
                string d=dgv.Rows[i].Cells["Durum"].Value?.ToString()??"Girdi";
                if(d=="Girdi"&&(string.IsNullOrWhiteSpace(v)||string.IsNullOrWhiteSpace(f)))eksikler.Add(i);
            }

            if(eksikler.Count>0){
                var r=MessageBox.Show($"{eksikler.Count} ogrencinin notu girilmemis.\n\nBu ogrencileri 'Girmedi' olarak isaretleyip notlarini 0 yapmak ister misiniz?\n\nEvet: 0 olarak kaydet\nHayir: Iptal et","Eksik Notlar",MessageBoxButtons.YesNoCancel,MessageBoxIcon.Question);
                if(r==DialogResult.Cancel||r==DialogResult.No)return;
                foreach(int i in eksikler){
                    dgv.Rows[i].Cells["Durum"].Value="Girmedi";
                    dgv.Rows[i].Cells["Vize"].Value="0";
                    dgv.Rows[i].Cells["Final"].Value="0";
                    HarfGuncelle(i);
                }
            }

            int basarili=0,hatali=0;
            var hataListesi=new List<string>();
            try{
                using var cn=Db.Baglanti(); cn.Open();
                for(int i=0;i<dgv.Rows.Count;i++){
                    int ogrId=satirlar[i].OgrenciID;
                    string ogrAd=satirlar[i].AdSoyad;
                    string d=dgv.Rows[i].Cells["Durum"].Value?.ToString()??"Girdi";
                    string vs=dgv.Rows[i].Cells["Vize"].Value?.ToString()??"";
                    string fs=dgv.Rows[i].Cells["Final"].Value?.ToString()??"";

                    int vize=0,final=0;
                    if(d=="Girdi"){
                        if(!int.TryParse(vs,out vize)||!int.TryParse(fs,out final)){
                            hatali++; hataListesi.Add($"{ogrAd}: gecersiz sayi");
                            continue;
                        }
                        if(vize<0||vize>100||final<0||final>100){
                            hatali++; hataListesi.Add($"{ogrAd}: not 0-100 arasinda olmali");
                            continue;
                        }
                    }
                    string harf=S.HarfNotu(vize*0.4+final*0.6);
                    try{
                        using var cmd=new SqlCommand("IF EXISTS(SELECT 1 FROM Notlar WHERE OgrenciID=@o AND DersID=@d)UPDATE Notlar SET VizeNotu=@v,FinalNotu=@f,HarfNotu=@h WHERE OgrenciID=@o AND DersID=@d ELSE INSERT INTO Notlar(OgrenciID,DersID,VizeNotu,FinalNotu,HarfNotu)VALUES(@o,@d,@v,@f,@h)",cn);
                        cmd.Parameters.AddWithValue("@o",ogrId);cmd.Parameters.AddWithValue("@d",dersId);
                        cmd.Parameters.AddWithValue("@v",vize);cmd.Parameters.AddWithValue("@f",final);
                        cmd.Parameters.AddWithValue("@h",harf);
                        int etki=cmd.ExecuteNonQuery();
                        if(etki>0)basarili++;
                        else{hatali++; hataListesi.Add($"{ogrAd}: veritabanina yazilamadi");}
                    }catch(Exception exIn){
                        hatali++; hataListesi.Add($"{ogrAd}: {exIn.Message}");
                    }

                    // Devamsizlik kaydi (sadece Girmedi/Devamsiz icin)
                    if(d!="Girdi"){
                        try{using var cmd2=new SqlCommand("IF NOT EXISTS(SELECT 1 FROM Devamsizlik WHERE OgrenciID=@o AND DersID=@d AND Tarih=CAST(GETDATE() AS DATE))INSERT INTO Devamsizlik(OgrenciID,DersID,Tarih,Durum,Aciklama)VALUES(@o,@d,CAST(GETDATE() AS DATE),'Gelmedi',@a)",cn);
                            cmd2.Parameters.AddWithValue("@o",ogrId);cmd2.Parameters.AddWithValue("@d",dersId);
                            cmd2.Parameters.AddWithValue("@a",d=="Devamsiz"?"Devamsiz":"Sinava girmedi");
                            cmd2.ExecuteNonQuery();
                        }catch{}
                    }
                }
                string msg=$"KAYIT ISLEMI TAMAMLANDI\n\n✓ Basarili: {basarili}\n";
                if(hatali>0){
                    msg+=$"✗ Hatali: {hatali}\n\nHatalar:\n";
                    foreach(var h in hataListesi)msg+=$"- {h}\n";
                }
                MessageBox.Show(msg,"Sonuc",MessageBoxButtons.OK,hatali>0?MessageBoxIcon.Warning:MessageBoxIcon.Information);
                if(basarili>0)Close();
            }catch(Exception ex){
                MessageBox.Show($"Kritik hata:\n\n{ex.Message}","Hata",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }
    }

    public class OgretmenListesiEkrani : Form
    {
        private DataGridView dgv;
        public OgretmenListesiEkrani(){Text="Ogretmen Listesi";Size=new Size(750,520);S.Apply(this);var t=S.Lbl("Ogretmen Listesi",S.H1);t.ForeColor=S.Accent;t.Location=new Point(260,10);Controls.Add(t);dgv=S.Dgv();dgv.Location=new Point(35,55);dgv.Size=new Size(670,310);Controls.Add(dgv);var eb=S.Btn("Ogretmen Ekle",S.BtnGreen,170,40);eb.Location=new Point(35,380);eb.Click+=(s,e)=>{Nav.GitDialog(new OgretmenEkleForm());Yukle();};Controls.Add(eb);var gb=S.Btn("Guncelle",S.BtnBlue,170,40);gb.Location=new Point(225,380);gb.Click+=(s,e)=>{if(dgv.SelectedRows.Count>0){Nav.GitDialog(new OgretmenEkleForm(Convert.ToInt32(dgv.SelectedRows[0].Cells["OgretmenID"].Value)));Yukle();}};Controls.Add(gb);var sb=S.Btn("Sil",S.BtnRed,170,40);sb.Location=new Point(415,380);sb.Click+=(s,e)=>{if(dgv.SelectedRows.Count==0)return;if(MessageBox.Show("Silmek istediginize emin misiniz?","Onay",MessageBoxButtons.YesNo)==DialogResult.Yes){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("DELETE FROM Ogretmenler WHERE OgretmenID=@id",cn);cmd.Parameters.AddWithValue("@id",Convert.ToInt32(dgv.SelectedRows[0].Cells["OgretmenID"].Value));cmd.ExecuteNonQuery();Yukle();}catch(Exception ex){MessageBox.Show($"Silme hatasi: {ex.Message}");}}};Controls.Add(sb);var geri=S.Btn("Geri",S.BtnDef,120,40);geri.Location=new Point(600,380);geri.Click+=(s,e)=>Close();Controls.Add(geri);Yukle();}
        void Yukle(){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT o.OgretmenID,o.Unvan,o.Ad,o.Soyad,b.BolumAdi AS[Bolum],o.Telefon,o.Email FROM Ogretmenler o INNER JOIN Bolumler b ON o.BolumID=b.BolumID ORDER BY o.Soyad",cn);var dt=new DataTable();dt.Load(cmd.ExecuteReader());dgv.DataSource=dt;if(dgv.Columns.Contains("OgretmenID"))dgv.Columns["OgretmenID"].Visible=false;}catch(Exception ex){MessageBox.Show(ex.Message);}}
    }

    public class OgretmenEkleForm : Form
    {
        private TextBox txtAd,txtSoyad,txtUnvan,txtTel,txtEmail;private ComboBox cmbBol;private int? id;
        public OgretmenEkleForm(int? ogrtId=null){id=ogrtId;Text=id.HasValue?"Ogretmen Guncelle":"Ogretmen Ekle";Size=new Size(450,420);S.Apply(this);var t=S.Lbl(Text,S.H2);t.ForeColor=S.Accent;t.Location=new Point(110,10);Controls.Add(t);var p=S.Pnl(390,270);p.Location=new Point(25,45);int lx=15,tx=115,y=10,g=45;p.Controls.Add(S.FLbl("Ad:",lx,y));txtAd=S.Tb(230);txtAd.Location=new Point(tx,y);p.Controls.Add(txtAd);y+=g;p.Controls.Add(S.FLbl("Soyad:",lx,y));txtSoyad=S.Tb(230);txtSoyad.Location=new Point(tx,y);p.Controls.Add(txtSoyad);y+=g;p.Controls.Add(S.FLbl("Unvan:",lx,y));txtUnvan=S.Tb(230);txtUnvan.Location=new Point(tx,y);p.Controls.Add(txtUnvan);y+=g;p.Controls.Add(S.FLbl("Bolum:",lx,y));cmbBol=S.Cmb(230);cmbBol.Location=new Point(tx,y);p.Controls.Add(cmbBol);y+=g;p.Controls.Add(S.FLbl("Telefon:",lx,y));txtTel=S.Tb(230);txtTel.Location=new Point(tx,y);p.Controls.Add(txtTel);y+=g;p.Controls.Add(S.FLbl("Email:",lx,y));txtEmail=S.Tb(230);txtEmail.Location=new Point(tx,y);p.Controls.Add(txtEmail);Controls.Add(p);var kb=S.Btn("Kaydet",S.BtnGreen,150,38);kb.Location=new Point(45,330);kb.Click+=Kay;Controls.Add(kb);var ib=S.Btn("Iptal",S.BtnRed,150,38);ib.Location=new Point(240,330);ib.Click+=(s,e)=>Close();Controls.Add(ib);try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT BolumID,BolumAdi FROM Bolumler ORDER BY BolumAdi",cn);using var rd=cmd.ExecuteReader();while(rd.Read())cmbBol.Items.Add(new CItem{ID=rd.GetInt32(0),Ad=rd.GetString(1)});if(cmbBol.Items.Count>0)cmbBol.SelectedIndex=0;}catch{} if(id.HasValue){try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT Ad,Soyad,Unvan,BolumID,Telefon,Email FROM Ogretmenler WHERE OgretmenID=@id",cn);cmd.Parameters.AddWithValue("@id",id.Value);using var rd=cmd.ExecuteReader();if(rd.Read()){txtAd.Text=rd.GetString(0);txtSoyad.Text=rd.GetString(1);txtUnvan.Text=rd.IsDBNull(2)?"":rd.GetString(2);int bid=rd.GetInt32(3);for(int i=0;i<cmbBol.Items.Count;i++)if(((CItem)cmbBol.Items[i]).ID==bid){cmbBol.SelectedIndex=i;break;}txtTel.Text=rd.IsDBNull(4)?"":rd.GetString(4);txtEmail.Text=rd.IsDBNull(5)?"":rd.GetString(5);}}catch{}}}
        void Kay(object? s,EventArgs e){if(string.IsNullOrWhiteSpace(txtAd.Text)||string.IsNullOrWhiteSpace(txtSoyad.Text)){MessageBox.Show("Ad ve Soyad zorunlu!");return;}try{using var cn=Db.Baglanti();cn.Open();int bid=((CItem)cmbBol.SelectedItem!).ID;if(id.HasValue){using var cmd=new SqlCommand("UPDATE Ogretmenler SET Ad=@a,Soyad=@s,Unvan=@u,BolumID=@b,Telefon=@t,Email=@e WHERE OgretmenID=@id",cn);cmd.Parameters.AddWithValue("@a",txtAd.Text);cmd.Parameters.AddWithValue("@s",txtSoyad.Text);cmd.Parameters.AddWithValue("@u",(object?)txtUnvan.Text??DBNull.Value);cmd.Parameters.AddWithValue("@b",bid);cmd.Parameters.AddWithValue("@t",txtTel.Text);cmd.Parameters.AddWithValue("@e",txtEmail.Text);cmd.Parameters.AddWithValue("@id",id.Value);cmd.ExecuteNonQuery();MessageBox.Show("Guncellendi!");}else{using var cmd=new SqlCommand("INSERT INTO Ogretmenler(Ad,Soyad,Unvan,BolumID,Telefon,Email)VALUES(@a,@s,@u,@b,@t,@e)",cn);cmd.Parameters.AddWithValue("@a",txtAd.Text);cmd.Parameters.AddWithValue("@s",txtSoyad.Text);cmd.Parameters.AddWithValue("@u",(object?)txtUnvan.Text??DBNull.Value);cmd.Parameters.AddWithValue("@b",bid);cmd.Parameters.AddWithValue("@t",txtTel.Text);cmd.Parameters.AddWithValue("@e",txtEmail.Text);cmd.ExecuteNonQuery();MessageBox.Show("Eklendi!");}Close();}catch(Exception ex){MessageBox.Show(ex.Message);}}
    }
}
