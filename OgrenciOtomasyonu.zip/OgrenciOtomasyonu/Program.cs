using System;
using System.Windows.Forms;
using OgrenciOtomasyonu.Forms;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (!Db.Test())
                if (MessageBox.Show("SQL Server baglantisi kurulamiyor!\n\n1. SQL Server calisiyor mu?\n2. OgrenciOtomasyonDB olusturuldu mu?\n\nDevam?", "Uyari", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.No) return;
            Application.Run(new AnaGirisEkrani());
        }
    }
}
