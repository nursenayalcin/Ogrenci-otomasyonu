-- =====================================================
-- SAHTE VERİ EKLEME - FINAL
-- =====================================================
USE OgrenciOtomasyonDB;
GO

SET IDENTITY_INSERT Bolumler ON;
INSERT INTO Bolumler (BolumID,BolumAdi,BolumKodu) VALUES
(1,N'Bilgisayar Teknolojisi',N'BT'),(2,N'Bilgisayar Programciligi',N'BP'),
(3,N'Elektrik',N'ELK'),(4,N'Elektronik Teknolojisi',N'ET'),
(5,N'Makine',N'MAK'),(6,N'Insaat Teknolojisi',N'INS'),
(7,N'Muhasebe ve Vergi',N'MV'),(8,N'Isletme Yonetimi',N'IY'),
(9,N'Cocuk Gelisimi',N'CG'),(10,N'Gida Teknolojisi',N'GT');
SET IDENTITY_INSERT Bolumler OFF;
GO

SET IDENTITY_INSERT Ogretmenler ON;
INSERT INTO Ogretmenler (OgretmenID,Ad,Soyad,Unvan,BolumID,Email,Telefon) VALUES
(1,N'Ahmet',N'Yilmaz',N'Dr. Ogr. Uyesi',1,N'ahmet.yilmaz@kmyo.edu.tr',N'0532-111-2233'),
(2,N'Fatma',N'Kaya',N'Ogr. Gor.',1,N'fatma.kaya@kmyo.edu.tr',N'0533-222-3344'),
(3,N'Mehmet',N'Demir',N'Ogr. Gor.',2,N'mehmet.demir@kmyo.edu.tr',N'0534-333-4455'),
(4,N'Ayse',N'Celik',N'Dr. Ogr. Uyesi',2,N'ayse.celik@kmyo.edu.tr',N'0535-444-5566'),
(5,N'Hasan',N'Ozturk',N'Prof. Dr.',3,N'hasan.ozturk@kmyo.edu.tr',N'0536-555-6677'),
(6,N'Elif',N'Arslan',N'Ogr. Gor.',4,N'elif.arslan@kmyo.edu.tr',N'0537-666-7788'),
(7,N'Ali',N'Korkmaz',N'Doc. Dr.',5,N'ali.korkmaz@kmyo.edu.tr',N'0538-777-8899'),
(8,N'Zeynep',N'Sahin',N'Ogr. Gor.',6,N'zeynep.sahin@kmyo.edu.tr',N'0539-888-9900'),
(9,N'Mustafa',N'Erdogan',N'Dr. Ogr. Uyesi',7,N'mustafa.erdogan@kmyo.edu.tr',N'0540-999-0011'),
(10,N'Hatice',N'Aydin',N'Ogr. Gor.',8,N'hatice.aydin@kmyo.edu.tr',N'0541-000-1122');
SET IDENTITY_INSERT Ogretmenler OFF;
GO

SET IDENTITY_INSERT Ogrenciler ON;
INSERT INTO Ogrenciler (OgrenciID,OgrenciNo,Ad,Soyad,DogumTarihi,BolumID,Sinif,Email,Telefon) VALUES
(1,N'2024BT001',N'Nursena',N'Yalcin','2004-05-15',1,2,N'nursena.yalcin@stu.kmyo.edu.tr',N'0551-111-0001'),
(2,N'2024BT002',N'Mustafa Turan',N'Arslan','2003-11-20',1,2,N'mustafa.arslan@stu.kmyo.edu.tr',N'0552-222-0002'),
(3,N'2024BT003',N'Fidan',N'Hakkari','2004-03-10',1,2,N'fidan.hakkari@stu.kmyo.edu.tr',N'0553-333-0003'),
(4,N'2024BT004',N'Bilal',N'Iscimen','2003-08-25',1,2,N'bilal.iscimen@stu.kmyo.edu.tr',N'0554-444-0004'),
(5,N'2024BT005',N'Elif',N'Yildiz','2005-01-12',1,1,N'elif.yildiz@stu.kmyo.edu.tr',N'0555-555-0005'),
(6,N'2024BP001',N'Kaan',N'Aksoy','2004-07-08',2,1,N'kaan.aksoy@stu.kmyo.edu.tr',N'0556-666-0006'),
(7,N'2024BP002',N'Selin',N'Koc','2003-12-30',2,2,N'selin.koc@stu.kmyo.edu.tr',N'0557-777-0007'),
(8,N'2024ELK001',N'Burak',N'Yilmaz','2004-09-18',3,1,N'burak.yilmaz@stu.kmyo.edu.tr',N'0558-888-0008'),
(9,N'2024ET001',N'Deniz',N'Kara','2003-06-22',4,2,N'deniz.kara@stu.kmyo.edu.tr',N'0559-999-0009'),
(10,N'2024MAK001',N'Emre',N'Sen','2005-02-14',5,1,N'emre.sen@stu.kmyo.edu.tr',N'0560-000-0010'),
(11,N'2024INS001',N'Merve',N'Cetin','2004-04-05',6,2,N'merve.cetin@stu.kmyo.edu.tr',N'0561-111-0011'),
(12,N'2024MV001',N'Oguz Han',N'Kilic','2003-10-28',7,1,N'oguz.kilic@stu.kmyo.edu.tr',N'0562-222-0012'),
(13,N'2024IY001',N'Aylin',N'Dogan','2004-08-16',8,2,N'aylin.dogan@stu.kmyo.edu.tr',N'0563-333-0013'),
(14,N'2024CG001',N'Sude',N'Acar','2005-03-21',9,1,N'sude.acar@stu.kmyo.edu.tr',N'0564-444-0014'),
(15,N'2024GT001',N'Enes',N'Gunes','2004-11-09',10,2,N'enes.gunes@stu.kmyo.edu.tr',N'0565-555-0015');
SET IDENTITY_INSERT Ogrenciler OFF;
GO

SET IDENTITY_INSERT Kullanicilar ON;
INSERT INTO Kullanicilar (KullaniciID,KullaniciAdi,Sifre,Rol,IlgiliID) VALUES
(1,N'ogrenci1',N'123456',N'Ogrenci',1),(2,N'ogrenci2',N'123456',N'Ogrenci',2),
(3,N'ogrenci3',N'123456',N'Ogrenci',3),(4,N'ogrenci4',N'123456',N'Ogrenci',4),
(5,N'ogrenci5',N'123456',N'Ogrenci',5),(6,N'ogrenci6',N'123456',N'Ogrenci',6),
(7,N'ogrenci7',N'123456',N'Ogrenci',7),(8,N'ogrenci8',N'123456',N'Ogrenci',8),
(9,N'ogrenci9',N'123456',N'Ogrenci',9),(10,N'ogrenci10',N'123456',N'Ogrenci',10),
(11,N'akademisyen1',N'123456',N'Akademisyen',1),(12,N'akademisyen2',N'123456',N'Akademisyen',2),
(13,N'akademisyen3',N'123456',N'Akademisyen',3),
(14,N'admin1',N'123456',N'Admin',NULL),(15,N'admin2',N'123456',N'Admin',NULL),
(16,N'ogrenci11',N'123456',N'Ogrenci',11),(17,N'ogrenci12',N'123456',N'Ogrenci',12),
(18,N'ogrenci13',N'123456',N'Ogrenci',13);
SET IDENTITY_INSERT Kullanicilar OFF;
GO

SET IDENTITY_INSERT Dersler ON;
INSERT INTO Dersler (DersID,DersKodu,DersAdi,Kredi,BolumID,OgretmenID,Donem) VALUES
(1,N'BT101',N'Programlama Temelleri',4,1,1,N'2025-2026 Guz'),
(2,N'BT102',N'Veritabani Yonetimi',3,1,2,N'2025-2026 Guz'),
(3,N'BT201',N'Sistem Analizi ve Tasarimi',3,1,1,N'2025-2026 Bahar'),
(4,N'BT202',N'Web Programlama',4,1,2,N'2025-2026 Bahar'),
(5,N'BT103',N'Bilgisayar Aglari',3,1,1,N'2025-2026 Guz'),
(6,N'BP101',N'Nesne Yonelimli Programlama',4,2,3,N'2025-2026 Guz'),
(7,N'BP102',N'Veri Yapilari',3,2,4,N'2025-2026 Bahar'),
(8,N'ELK101',N'Devre Analizi',4,3,5,N'2025-2026 Guz'),
(9,N'ET101',N'Dijital Elektronik',3,4,6,N'2025-2026 Guz'),
(10,N'MAK101',N'Teknik Resim',3,5,7,N'2025-2026 Guz'),
(11,N'INS101',N'Yapi Malzemeleri',3,6,8,N'2025-2026 Guz'),
(12,N'MV101',N'Genel Muhasebe',4,7,9,N'2025-2026 Guz');
SET IDENTITY_INSERT Dersler OFF;
GO

INSERT INTO DersKayitlari (OgrenciID,DersID,Durum) VALUES
(1,1,N'Aktif'),(1,2,N'Aktif'),(1,3,N'Aktif'),(1,5,N'Aktif'),
(2,1,N'Aktif'),(2,2,N'Aktif'),(2,3,N'Aktif'),
(3,1,N'Aktif'),(3,2,N'Aktif'),(3,4,N'Aktif'),
(4,1,N'Aktif'),(4,3,N'Aktif'),(4,5,N'Aktif'),
(5,1,N'Aktif'),(5,2,N'Aktif'),
(6,6,N'Aktif'),(6,7,N'Aktif'),
(7,6,N'Aktif'),(7,7,N'Aktif'),
(8,8,N'Aktif'),(9,9,N'Aktif'),(10,10,N'Aktif'),
(11,11,N'Aktif'),(12,12,N'Aktif');
GO

INSERT INTO Notlar (OgrenciID,DersID,VizeNotu,FinalNotu,HarfNotu) VALUES
(1,1,85,90,N'AA'),(1,2,78,82,N'BA'),(1,3,92,88,N'AA'),
(2,1,70,65,N'CB'),(2,2,55,60,N'CC'),(2,3,80,75,N'BB'),
(3,1,90,95,N'AA'),(3,2,60,55,N'CC'),
(4,1,45,50,N'DC'),(4,3,72,68,N'CB'),
(5,1,88,92,N'AA'),(5,2,65,70,N'CB'),
(6,6,75,80,N'BB'),(7,6,82,78,N'BA'),(8,8,58,62,N'CC');
GO

INSERT INTO Devamsizlik (OgrenciID,DersID,Tarih,Durum,Aciklama) VALUES
(1,1,'2026-03-03',N'Geldi',NULL),(1,1,'2026-03-10',N'Gelmedi',N'Saglik raporu'),
(1,2,'2026-03-04',N'Geldi',NULL),(1,3,'2026-03-05',N'Geldi',NULL),
(2,1,'2026-03-03',N'Geldi',NULL),(2,1,'2026-03-10',N'Geldi',NULL),
(2,2,'2026-03-04',N'Gelmedi',NULL),(3,1,'2026-03-03',N'Geldi',NULL),
(3,1,'2026-03-10',N'Izinli',N'Aile izni'),(4,1,'2026-03-03',N'Gelmedi',NULL),
(5,1,'2026-03-03',N'Geldi',NULL),(6,6,'2026-03-06',N'Geldi',NULL),
(7,6,'2026-03-06',N'Gelmedi',NULL),(8,8,'2026-03-07',N'Geldi',NULL),
(9,9,'2026-03-08',N'Geldi',NULL);
GO

INSERT INTO Duyurular (Baslik,Icerik,OlusturanID) VALUES
(N'Bahar Donemi Ders Kayitlari',N'2025-2026 Bahar donemi ders kayitlari 10-14 Subat tarihleri arasinda yapilacaktir.',14),
(N'Vize Sinav Programi Aciklandi',N'Vize sinav programi ilan panosunda ve web sitesinde yayinlanmistir.',14),
(N'Proje Teslim Tarihi Hatirlatma',N'Sistem Analizi ve Tasarimi dersi 4. hafta odevi 12 Mart 2026 tarihine kadar teslim edilmelidir.',11),
(N'Staj Basvurulari Basladi',N'Yaz donemi staj basvurulari 1 Nisan tarihinde baslayacaktir.',14),
(N'Kutuphane Calisma Saatleri',N'Sinav doneminde kutuphane 08:00-22:00 arasi acik olacaktir.',15),
(N'Mezuniyet Toreni Duyurusu',N'2025-2026 mezuniyet toreni 20 Haziran 2026 tarihinde yapilacaktir.',14),
(N'Burs Basvurulari',N'KYK burs basvurulari icin son tarih 28 Subat 2026 dir.',15),
(N'Laboratuvar Kullanim Kurallari',N'Bilgisayar laboratuvari kullanim kurallari guncellendi.',11),
(N'Final Sinav Programi',N'Final sinav programi 15 Mayis 2026 tarihinde aciklanacaktir.',14),
(N'Teknik Gezi Duyurusu',N'Bilgisayar Teknolojisi bolumu ogrencileri icin 15 Mart ta teknik gezi duzenlenecektir.',12);
GO

PRINT N'Tum sahte veriler basariyla eklendi!';
GO

SELECT 'Bolumler' AS Tablo,COUNT(*) AS Sayi FROM Bolumler
UNION ALL SELECT 'Kullanicilar',COUNT(*) FROM Kullanicilar
UNION ALL SELECT 'Ogretmenler',COUNT(*) FROM Ogretmenler
UNION ALL SELECT 'Ogrenciler',COUNT(*) FROM Ogrenciler
UNION ALL SELECT 'Dersler',COUNT(*) FROM Dersler
UNION ALL SELECT 'DersKayitlari',COUNT(*) FROM DersKayitlari
UNION ALL SELECT 'Notlar',COUNT(*) FROM Notlar
UNION ALL SELECT 'Devamsizlik',COUNT(*) FROM Devamsizlik
UNION ALL SELECT 'Duyurular',COUNT(*) FROM Duyurular;
GO
