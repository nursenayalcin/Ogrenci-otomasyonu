using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class OgrenciMenuEkrani : Form
    {
        private int ogrenciId;
        public OgrenciMenuEkrani(string user, int ogrId)
        {
            ogrenciId = ogrId;
            Text = $"Ogrenci Paneli - {user}"; Size = new Size(600, 500); S.Apply(this);
            var tp = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(40, 40, 40) };
            var t = S.Lbl("Ogrenci Paneli", S.H1); t.ForeColor = S.Accent; t.Location = new Point(190, 15); tp.Controls.Add(t); Controls.Add(tp);
            var ul = S.Lbl($"Hos geldiniz: {user}", S.Small); ul.ForeColor = S.Dim; ul.Location = new Point(220, 75); Controls.Add(ul);

            int bw = 280, bh = 48, sx = 155, sy = 105, g = 58;
            AddBtn("Derslerimi Goruntule", S.BtnDef, sx, sy, bw, bh, () => new OgrenciDersleriEkrani(ogrenciId).ShowDialog());
            AddBtn("Notlarimi Goruntule", S.BtnDef, sx, sy + g, bw, bh, () => new OgrenciNotlariEkrani(ogrenciId).ShowDialog());
            AddBtn("Ortalama Gor", S.BtnBlue, sx, sy + g * 2, bw, bh, () => OrtalamaGoster());
            AddBtn("Transkript Gor", S.BtnBlue, sx, sy + g * 3, bw, bh, () => new TranskriptEkrani(ogrenciId).ShowDialog());
            AddBtn("Profilimi Guncelle", S.BtnOrange, sx, sy + g * 4, bw, bh, () => new ProfilGuncelleEkrani(ogrenciId).ShowDialog());
            AddBtn("Cikis", S.BtnRed, sx, sy + g * 5, bw, bh, () => Close());
        }

        private void AddBtn(string t, Color c, int x, int y, int w, int h, Action act)
        { var b = S.Btn(t, c, w, h); b.Location = new Point(x, y); b.Click += (s, e) => act(); Controls.Add(b); }

        private void OrtalamaGoster()
        {
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using var cmd = new SqlCommand("SELECT AVG(Ortalama) FROM Notlar WHERE OgrenciID=@id AND Ortalama IS NOT NULL", cn);
                cmd.Parameters.AddWithValue("@id", ogrenciId);
                var r = cmd.ExecuteScalar();
                string ort = r == DBNull.Value ? "Henuz not girilmemis" : $"{Convert.ToDecimal(r):F2}";
                MessageBox.Show($"Genel Not Ortalamaniz: {ort}", "Ortalama", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
        }
    }

    public class OgrenciDersleriEkrani : Form
    {
        public OgrenciDersleriEkrani(int ogrId)
        {
            Text = "Derslerim"; Size = new Size(700, 400); S.Apply(this);
            var t = S.Lbl("Kayitli Oldugum Dersler", S.H2); t.ForeColor = S.Accent; t.Location = new Point(210, 10); Controls.Add(t);
            var dgv = S.Dgv(); dgv.Location = new Point(30, 45); dgv.Size = new Size(630, 290); Controls.Add(dgv);
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using var cmd = new SqlCommand(@"SELECT d.DersKodu AS[Ders Kodu],d.DersAdi AS[Ders Adi],d.Kredi,
                    o.Ad+' '+o.Soyad AS[Ogretmen],dk.Durum FROM DersKayitlari dk
                    INNER JOIN Dersler d ON dk.DersID=d.DersID LEFT JOIN Ogretmenler o ON d.OgretmenID=o.OgretmenID
                    WHERE dk.OgrenciID=@id ORDER BY d.DersKodu", cn);
                cmd.Parameters.AddWithValue("@id", ogrId); var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt;
            }
            catch { }
            var gb = S.Btn("Geri", S.BtnDef, 120, 35); gb.Location = new Point(280, 345); gb.Click += (s, e) => Close(); Controls.Add(gb);
        }
    }

    public class OgrenciNotlariEkrani : Form
    {
        public OgrenciNotlariEkrani(int ogrId)
        {
            Text = "Notlarim"; Size = new Size(750, 420); S.Apply(this);
            var t = S.Lbl("Ders Notlarim", S.H2); t.ForeColor = S.Accent; t.Location = new Point(280, 10); Controls.Add(t);
            var dgv = S.Dgv(); dgv.Location = new Point(30, 45); dgv.Size = new Size(680, 300); Controls.Add(dgv);
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using var cmd = new SqlCommand(@"SELECT d.DersKodu AS[Ders Kodu],d.DersAdi AS[Ders Adi],n.VizeNotu AS[Vize],
                    n.FinalNotu AS[Final],n.Ortalama,n.HarfNotu AS[Harf Notu] FROM Notlar n
                    INNER JOIN Dersler d ON n.DersID=d.DersID WHERE n.OgrenciID=@id ORDER BY d.DersKodu", cn);
                cmd.Parameters.AddWithValue("@id", ogrId); var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt;
            }
            catch { }
            var gb = S.Btn("Geri", S.BtnDef, 120, 35); gb.Location = new Point(310, 360); gb.Click += (s, e) => Close(); Controls.Add(gb);
        }
    }

    public class TranskriptEkrani : Form
    {
        public TranskriptEkrani(int ogrId)
        {
            Text = "Transkript"; Size = new Size(800, 550); S.Apply(this);
            var t = S.Lbl("TRANSKRIPT", S.H1); t.ForeColor = S.Accent; t.Location = new Point(300, 10); Controls.Add(t);
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                string bilgi = "";
                using (var cmd = new SqlCommand("SELECT o.OgrenciNo,o.Ad+' '+o.Soyad,b.BolumAdi,o.Sinif FROM Ogrenciler o INNER JOIN Bolumler b ON o.BolumID=b.BolumID WHERE o.OgrenciID=@id", cn))
                {
                    cmd.Parameters.AddWithValue("@id", ogrId); using var rd = cmd.ExecuteReader();
                    if (rd.Read()) bilgi = $"No: {rd.GetString(0)}  |  {rd.GetString(1)}  |  {rd.GetString(2)}  |  Sinif: {rd.GetInt32(3)}";
                }
                var bl = S.Lbl(bilgi); bl.ForeColor = S.Dim; bl.Location = new Point(100, 50); Controls.Add(bl);

                var dgv = S.Dgv(); dgv.Location = new Point(30, 80); dgv.Size = new Size(730, 350); Controls.Add(dgv);
                using var cmd2 = new SqlCommand(@"SELECT d.DersKodu AS[Kod],d.DersAdi AS[Ders],d.Kredi,n.VizeNotu AS[Vize],
                    n.FinalNotu AS[Final],n.Ortalama,n.HarfNotu AS[Harf],
                    CASE WHEN n.Ortalama>=60 THEN 'Basarili' ELSE 'Basarisiz' END AS[Durum]
                    FROM Notlar n INNER JOIN Dersler d ON n.DersID=d.DersID WHERE n.OgrenciID=@id ORDER BY d.DersKodu", cn);
                cmd2.Parameters.AddWithValue("@id", ogrId); var dt = new DataTable(); dt.Load(cmd2.ExecuteReader()); dgv.DataSource = dt;

                decimal topPuan = 0; int topKredi = 0;
                foreach (DataRow row in dt.Rows)
                {
                    if (row["Ortalama"] != DBNull.Value)
                    { int kr = Convert.ToInt32(row["Kredi"]); decimal ort = Convert.ToDecimal(row["Ortalama"]); topKredi += kr; topPuan += ort * kr / 25; }
                }
                decimal gno = topKredi > 0 ? topPuan / topKredi : 0;
                var gl = S.Lbl($"Genel Not Ortalamasi (GNO): {gno:F2} / 4.00", S.H2);
                gl.ForeColor = gno >= 2 ? Color.LimeGreen : Color.Red;
                gl.Location = new Point(200, 445); Controls.Add(gl);
            }
            catch { }
            var gb = S.Btn("Geri", S.BtnDef, 120, 35); gb.Location = new Point(30, 490); gb.Click += (s, e) => Close(); Controls.Add(gb);
        }
    }

    public class ProfilGuncelleEkrani : Form
    {
        private TextBox txtEmail, txtTelefon;
        private int ogrId;
        public ProfilGuncelleEkrani(int ogrenciId)
        {
            ogrId = ogrenciId; Text = "Profil Guncelle"; Size = new Size(450, 350); S.Apply(this);
            var t = S.Lbl("Profil Guncelle", S.H2); t.ForeColor = S.Accent; t.Location = new Point(130, 10); Controls.Add(t);
            var p = S.Pnl(380, 180); p.Location = new Point(30, 50);
            p.Controls.Add(S.FLbl("Ad Soyad:", 20, 20));
            var txtAd = S.Tb(220); txtAd.Location = new Point(130, 20); txtAd.ReadOnly = true; txtAd.BackColor = Color.FromArgb(50, 50, 50); p.Controls.Add(txtAd);
            p.Controls.Add(S.FLbl("Email:", 20, 70));
            txtEmail = S.Tb(220); txtEmail.Location = new Point(130, 70); p.Controls.Add(txtEmail);
            p.Controls.Add(S.FLbl("Telefon:", 20, 120));
            txtTelefon = S.Tb(220); txtTelefon.Location = new Point(130, 120); p.Controls.Add(txtTelefon);
            Controls.Add(p);

            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using var cmd = new SqlCommand("SELECT Ad+' '+Soyad,Email,Telefon FROM Ogrenciler WHERE OgrenciID=@id", cn);
                cmd.Parameters.AddWithValue("@id", ogrId); using var rd = cmd.ExecuteReader();
                if (rd.Read()) { txtAd.Text = rd.GetString(0); txtEmail.Text = rd.IsDBNull(1) ? "" : rd.GetString(1); txtTelefon.Text = rd.IsDBNull(2) ? "" : rd.GetString(2); }
            }
            catch { }

            var kb = S.Btn("Kaydet", S.BtnGreen, 150, 38); kb.Location = new Point(60, 250);
            kb.Click += (s, e) =>
            {
                try
                {
                    using var cn = Db.Baglanti(); cn.Open();
                    using var cmd = new SqlCommand("UPDATE Ogrenciler SET Email=@e,Telefon=@t WHERE OgrenciID=@id", cn);
                    cmd.Parameters.AddWithValue("@e", txtEmail.Text); cmd.Parameters.AddWithValue("@t", txtTelefon.Text); cmd.Parameters.AddWithValue("@id", ogrId);
                    cmd.ExecuteNonQuery(); MessageBox.Show("Profil guncellendi!", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information); Close();
                }
                catch (Exception ex) { MessageBox.Show(ex.Message); }
            }; Controls.Add(kb);
            var ib = S.Btn("Iptal", S.BtnRed, 150, 38); ib.Location = new Point(230, 250); ib.Click += (s, e) => Close(); Controls.Add(ib);
        }
    }
}
