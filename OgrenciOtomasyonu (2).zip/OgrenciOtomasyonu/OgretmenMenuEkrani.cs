using System;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class OgretmenMenuEkrani : Form
    {
        private int ogretmenId;
        public OgretmenMenuEkrani(string user, int ogrtId)
        {
            ogretmenId = ogrtId;
            Text = $"Ogretmen Paneli - {user}"; Size = new Size(600, 450); S.Apply(this);
            var tp = new Panel { Dock = DockStyle.Top, Height = 60, BackColor = Color.FromArgb(40, 40, 40) };
            var t = S.Lbl("Ogretmen Paneli", S.H1); t.ForeColor = S.Accent; t.Location = new Point(180, 15); tp.Controls.Add(t); Controls.Add(tp);
            var ul = S.Lbl($"Hos geldiniz: {user}", S.Small); ul.ForeColor = S.Dim; ul.Location = new Point(210, 75); Controls.Add(ul);

            int bw = 280, bh = 50, sx = 155, sy = 110, g = 65;
            var b1 = S.Btn("Kendi Derslerimi Goruntule", S.BtnDef, bw, bh); b1.Location = new Point(sx, sy);
            b1.Click += (s, e) => new OgretmenDersleriEkrani(ogretmenId).ShowDialog(); Controls.Add(b1);
            var b2 = S.Btn("Ogrenci Listesi Gor", S.BtnDef, bw, bh); b2.Location = new Point(sx, sy + g);
            b2.Click += (s, e) => new OgrenciListesiEkrani().ShowDialog(); Controls.Add(b2);
            var b3 = S.Btn("Not Gir / Guncelle", S.BtnBlue, bw, bh); b3.Location = new Point(sx, sy + g * 2);
            b3.Click += (s, e) => new NotGirisEkrani().ShowDialog(); Controls.Add(b3);
            var b4 = S.Btn("Cikis", S.BtnRed, bw, bh); b4.Location = new Point(sx, sy + g * 3);
            b4.Click += (s, e) => Close(); Controls.Add(b4);
        }
    }

    public class OgretmenDersleriEkrani : Form
    {
        public OgretmenDersleriEkrani(int ogretmenId)
        {
            Text = "Derslerim"; Size = new Size(650, 400); S.Apply(this);
            var t = S.Lbl("Derslerim", S.H1); t.ForeColor = S.Accent; t.Location = new Point(250, 10); Controls.Add(t);
            var dgv = S.Dgv(); dgv.Location = new Point(30, 50); dgv.Size = new Size(580, 280); Controls.Add(dgv);
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using var cmd = new SqlCommand("SELECT DersKodu AS[Ders Kodu],DersAdi AS[Ders Adi],Kredi,Donem FROM Dersler WHERE OgretmenID=@id ORDER BY DersKodu", cn);
                cmd.Parameters.AddWithValue("@id", ogretmenId);
                var dt = new DataTable(); dt.Load(cmd.ExecuteReader()); dgv.DataSource = dt;
            }
            catch (Exception ex) { MessageBox.Show(ex.Message); }
            var gb = S.Btn("Geri", S.BtnDef, 120, 35); gb.Location = new Point(260, 340); gb.Click += (s, e) => Close(); Controls.Add(gb);
        }
    }
}
