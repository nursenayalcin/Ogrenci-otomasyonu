-- =====================================================
-- ÖĞRENCI OTOMASYONU VERİTABANI - TAM SCRIPT
-- =====================================================
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = 'OgrenciOtomasyonDB')
    CREATE DATABASE OgrenciOtomasyonDB;
GO
USE OgrenciOtomasyonDB;
GO

IF OBJECT_ID('Devamsizlik','U') IS NOT NULL DROP TABLE Devamsizlik;
IF OBJECT_ID('Notlar','U') IS NOT NULL DROP TABLE Notlar;
IF OBJECT_ID('DersKayitlari','U') IS NOT NULL DROP TABLE DersKayitlari;
IF OBJECT_ID('Duyurular','U') IS NOT NULL DROP TABLE Duyurular;
IF OBJECT_ID('Dersler','U') IS NOT NULL DROP TABLE Dersler;
IF OBJECT_ID('Ogrenciler','U') IS NOT NULL DROP TABLE Ogrenciler;
IF OBJECT_ID('Ogretmenler','U') IS NOT NULL DROP TABLE Ogretmenler;
IF OBJECT_ID('Kullanicilar','U') IS NOT NULL DROP TABLE Kullanicilar;
IF OBJECT_ID('Bolumler','U') IS NOT NULL DROP TABLE Bolumler;
GO

CREATE TABLE Bolumler (
    BolumID INT IDENTITY(1,1) PRIMARY KEY,
    BolumAdi NVARCHAR(100) NOT NULL UNIQUE,
    BolumKodu NVARCHAR(10) NOT NULL UNIQUE,
    OlusturmaTarihi DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE Kullanicilar (
    KullaniciID INT IDENTITY(1,1) PRIMARY KEY,
    KullaniciAdi NVARCHAR(50) NOT NULL UNIQUE,
    Sifre NVARCHAR(256) NOT NULL,
    Rol NVARCHAR(20) NOT NULL CHECK (Rol IN ('Ogrenci','Akademisyen','Admin')),
    IlgiliID INT NULL,
    Aktif BIT DEFAULT 1,
    OlusturmaTarihi DATETIME DEFAULT GETDATE(),
    SonGirisTarihi DATETIME NULL
);
GO

CREATE TABLE Ogretmenler (
    OgretmenID INT IDENTITY(1,1) PRIMARY KEY,
    Ad NVARCHAR(50) NOT NULL,
    Soyad NVARCHAR(50) NOT NULL,
    Unvan NVARCHAR(50) NULL,
    BolumID INT NOT NULL REFERENCES Bolumler(BolumID),
    Email NVARCHAR(100) NULL,
    Telefon NVARCHAR(20) NULL,
    OlusturmaTarihi DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE Ogrenciler (
    OgrenciID INT IDENTITY(1,1) PRIMARY KEY,
    OgrenciNo NVARCHAR(20) NOT NULL UNIQUE,
    Ad NVARCHAR(50) NOT NULL,
    Soyad NVARCHAR(50) NOT NULL,
    DogumTarihi DATE NULL,
    BolumID INT NOT NULL REFERENCES Bolumler(BolumID),
    Sinif INT NOT NULL CHECK (Sinif BETWEEN 1 AND 4),
    Email NVARCHAR(100) NULL,
    Telefon NVARCHAR(20) NULL,
    KayitTarihi DATETIME DEFAULT GETDATE(),
    Aktif BIT DEFAULT 1
);
GO

CREATE TABLE Dersler (
    DersID INT IDENTITY(1,1) PRIMARY KEY,
    DersKodu NVARCHAR(10) NOT NULL UNIQUE,
    DersAdi NVARCHAR(100) NOT NULL,
    Kredi INT NOT NULL CHECK (Kredi BETWEEN 1 AND 10),
    BolumID INT NOT NULL REFERENCES Bolumler(BolumID),
    OgretmenID INT NULL REFERENCES Ogretmenler(OgretmenID),
    Donem NVARCHAR(30) NULL,
    OlusturmaTarihi DATETIME DEFAULT GETDATE()
);
GO

CREATE TABLE DersKayitlari (
    KayitID INT IDENTITY(1,1) PRIMARY KEY,
    OgrenciID INT NOT NULL REFERENCES Ogrenciler(OgrenciID),
    DersID INT NOT NULL REFERENCES Dersler(DersID),
    KayitTarihi DATETIME DEFAULT GETDATE(),
    Durum NVARCHAR(20) DEFAULT 'Aktif' CHECK (Durum IN ('Aktif','Birakti','Tamamladi')),
    CONSTRAINT UQ_OgrenciDers UNIQUE (OgrenciID, DersID)
);
GO

CREATE TABLE Notlar (
    NotID INT IDENTITY(1,1) PRIMARY KEY,
    OgrenciID INT NOT NULL REFERENCES Ogrenciler(OgrenciID),
    DersID INT NOT NULL REFERENCES Dersler(DersID),
    VizeNotu DECIMAL(5,2) NULL CHECK (VizeNotu BETWEEN 0 AND 100),
    FinalNotu DECIMAL(5,2) NULL CHECK (FinalNotu BETWEEN 0 AND 100),
    ButunlemeNotu DECIMAL(5,2) NULL CHECK (ButunlemeNotu BETWEEN 0 AND 100),
    Ortalama AS (CASE 
        WHEN ButunlemeNotu IS NOT NULL THEN (VizeNotu * 0.4 + ButunlemeNotu * 0.6)
        WHEN FinalNotu IS NOT NULL THEN (VizeNotu * 0.4 + FinalNotu * 0.6)
        ELSE NULL END) PERSISTED,
    HarfNotu NVARCHAR(2) NULL,
    GirisTarihi DATETIME DEFAULT GETDATE(),
    CONSTRAINT UQ_OgrenciDersNot UNIQUE (OgrenciID, DersID)
);
GO

CREATE TABLE Devamsizlik (
    DevamsizlikID INT IDENTITY(1,1) PRIMARY KEY,
    OgrenciID INT NOT NULL REFERENCES Ogrenciler(OgrenciID),
    DersID INT NOT NULL REFERENCES Dersler(DersID),
    Tarih DATE NOT NULL,
    Durum NVARCHAR(10) NOT NULL CHECK (Durum IN ('Geldi','Gelmedi','Izinli')),
    Aciklama NVARCHAR(200) NULL,
    CONSTRAINT UQ_DevamsizlikTarih UNIQUE (OgrenciID, DersID, Tarih)
);
GO

CREATE TABLE Duyurular (
    DuyuruID INT IDENTITY(1,1) PRIMARY KEY,
    Baslik NVARCHAR(200) NOT NULL,
    Icerik NVARCHAR(MAX) NOT NULL,
    OlusturanID INT NULL REFERENCES Kullanicilar(KullaniciID),
    OlusturmaTarihi DATETIME DEFAULT GETDATE(),
    Aktif BIT DEFAULT 1
);
GO

CREATE NONCLUSTERED INDEX IX_Ogrenciler_BolumID ON Ogrenciler(BolumID);
CREATE NONCLUSTERED INDEX IX_Dersler_BolumID ON Dersler(BolumID);
CREATE NONCLUSTERED INDEX IX_Dersler_OgretmenID ON Dersler(OgretmenID);
CREATE NONCLUSTERED INDEX IX_Notlar_OgrenciID ON Notlar(OgrenciID);
CREATE NONCLUSTERED INDEX IX_Notlar_DersID ON Notlar(DersID);
CREATE NONCLUSTERED INDEX IX_DersKayitlari_OgrenciID ON DersKayitlari(OgrenciID);
CREATE NONCLUSTERED INDEX IX_Devamsizlik_OgrenciID ON Devamsizlik(OgrenciID);
GO

PRINT N'Veritabani ve tablolar basariyla olusturuldu.';
GO
