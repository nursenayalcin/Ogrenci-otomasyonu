using System;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class AnaGirisEkrani : Form
    {
        public AnaGirisEkrani()
        {
            Text="Ogrenci Otomasyonu Sistemi";Size=new Size(800,600);S.Apply(this);
            var top=new Panel{Dock=DockStyle.Top,Height=70,BackColor=Color.FromArgb(40,40,40)};
            var t=S.Lbl("OGRENCI OTOMASYONU SISTEMI",S.H1);t.ForeColor=S.Accent;t.Location=new Point(150,20);top.Controls.Add(t);
            var info=S.Btn("BILGI / YARDIM",S.BtnDef,140,35);info.Location=new Point(630,18);info.Font=S.Small;
            info.Click+=(s,e)=>MessageBox.Show("Ogrenci Otomasyonu Sistemi v3.0\n\nKirikhan MYO - Bilgisayar Teknolojisi\nSistem Analizi ve Tasarimi Dersi\n2025-2026 Bahar","Bilgi",MessageBoxButtons.OK,MessageBoxIcon.Information);
            top.Controls.Add(info);Controls.Add(top);
            var p=S.Pnl(350,280);p.Location=new Point(225,160);
            var b1=S.Btn("OGRENCI GIRISI",S.BtnDef,260,50);b1.Location=new Point(45,40);b1.Click+=(s,e)=>Nav.Git(this,new LoginEkrani("Ogrenci"));p.Controls.Add(b1);
            var b2=S.Btn("AKADEMISYEN GIRISI",S.BtnDef,260,50);b2.Location=new Point(45,110);b2.Click+=(s,e)=>Nav.Git(this,new LoginEkrani("Akademisyen"));p.Controls.Add(b2);
            var b3=S.Btn("OGRENCI ISLERI (ADMIN) GIRISI",S.BtnDef,260,50);b3.Location=new Point(45,180);b3.Click+=(s,e)=>Nav.Git(this,new LoginEkrani("Admin"));p.Controls.Add(b3);
            Controls.Add(p);
        }
    }

    public class LoginEkrani : Form
    {
        private TextBox txtUser,txtPass,txtCode;
        private int n1,n2;private string rol;
        public LoginEkrani(string rol)
        {
            this.rol=rol;Text=$"Giris - {rol}";Size=new Size(500,560);S.Apply(this);
            var t=S.Lbl("OGRENCI OTOMASYONU",S.H2);t.ForeColor=S.Accent;t.Location=new Point(125,25);Controls.Add(t);
            var p=S.Pnl(380,360);p.Location=new Point(55,65);
            p.Controls.Add(S.Lbl("Kullanici Adi:"));p.Controls[0].Location=new Point(30,25);
            txtUser=S.Tb(300);txtUser.Location=new Point(30,50);p.Controls.Add(txtUser);
            p.Controls.Add(S.Lbl("Sifre:"));p.Controls[^1].Location=new Point(30,90);
            txtPass=S.Tb(300);txtPass.Location=new Point(30,115);txtPass.UseSystemPasswordChar=true;p.Controls.Add(txtPass);
            p.Controls.Add(S.Lbl("Guvenlik Kodu:"));p.Controls[^1].Location=new Point(30,155);
            var r=new Random();n1=r.Next(10,50);n2=r.Next(10,50);
            p.Controls.Add(new Label{Text=$"{n1}+{n2}=?",Font=new Font("Segoe UI",11,FontStyle.Bold),ForeColor=Color.Orange,AutoSize=true,Location=new Point(30,180)});
            txtCode=S.Tb(100);txtCode.Location=new Point(130,178);p.Controls.Add(txtCode);
            var gBtn=S.Btn("GIRIS",S.BtnBlue,120,38);gBtn.Location=new Point(240,175);gBtn.Click+=Giris;p.Controls.Add(gBtn);

            // Sifremi unuttum - acilir ekrana gider
            var link=new LinkLabel{Text="Sifremi unuttum? / Sifre Sifirla",Font=S.Small,LinkColor=Color.FromArgb(150,180,220),AutoSize=true,Location=new Point(90,225)};
            link.Click+=(s,e)=>Nav.Git(this,new SifreSifirlaEkrani());
            p.Controls.Add(link);

            // e-Devlet - gercek siteye yonlendir
            var eBtn=S.Btn("E - DEVLET GIRIS",Color.FromArgb(150,30,30),300,40);eBtn.Location=new Point(40,260);
            eBtn.Click+=(s,e)=>{try{Process.Start(new ProcessStartInfo("https://www.turkiye.gov.tr"){UseShellExecute=true});}catch{MessageBox.Show("Tarayici acilamadi!");}};
            p.Controls.Add(eBtn);

            var dBtn=S.Btn("Duyurular Icin Tiklayiniz",S.BtnDef,250,35);dBtn.Location=new Point(65,310);dBtn.Font=S.Small;
            dBtn.Click+=(s,e)=>Nav.Git(this,new DuyurularEkrani());p.Controls.Add(dBtn);
            Controls.Add(p);

            // Geri butonu
            var geri=S.Btn("Geri",S.BtnDef,100,35);geri.Location=new Point(10,490);geri.Click+=(s,e)=>Close();Controls.Add(geri);
            AcceptButton=gBtn;
        }
        private void Giris(object? s,EventArgs e)
        {
            if(string.IsNullOrWhiteSpace(txtUser.Text)||string.IsNullOrWhiteSpace(txtPass.Text)){MessageBox.Show("Kullanici adi ve sifre gerekli!");return;}
            if(!int.TryParse(txtCode.Text,out int c)||c!=n1+n2){MessageBox.Show("Guvenlik kodu hatali!");return;}
            try{
                using var cn=Db.Baglanti();cn.Open();
                using var cmd=new SqlCommand("SELECT KullaniciID,Rol,IlgiliID FROM Kullanicilar WHERE KullaniciAdi=@u AND Sifre=@p AND Aktif=1",cn);
                cmd.Parameters.AddWithValue("@u",txtUser.Text);cmd.Parameters.AddWithValue("@p",txtPass.Text);
                using var rd=cmd.ExecuteReader();
                if(rd.Read()){
                    string dbRol=rd.GetString(1);int? ilgId=rd.IsDBNull(2)?null:(int?)rd.GetInt32(2);
                    if(dbRol!=rol){MessageBox.Show("Bu kullanici bu rol tipinde degil!");return;}
                    rd.Close();
                    using var up=new SqlCommand("UPDATE Kullanicilar SET SonGirisTarihi=GETDATE() WHERE KullaniciAdi=@u",cn);
                    up.Parameters.AddWithValue("@u",txtUser.Text);up.ExecuteNonQuery();
                    Form menu;
                    if(dbRol=="Admin")menu=new AdminMenuEkrani(txtUser.Text);
                    else if(dbRol=="Akademisyen")menu=new OgretmenMenuEkrani(txtUser.Text,ilgId??0);
                    else menu=new OgrenciMenuEkrani(txtUser.Text,ilgId??0);
                    Nav.Git(this,menu);
                }else MessageBox.Show("Kullanici adi veya sifre hatali!");
            }catch(Exception ex){MessageBox.Show(Db.Hata(ex));}
        }
    }

    // Sifre sifirlama ekrani
    public class SifreSifirlaEkrani : Form
    {
        public SifreSifirlaEkrani()
        {
            Text="Sifre Sifirla";Size=new Size(400,280);S.Apply(this);
            var t=S.Lbl("Sifre Sifirla",S.H2);t.ForeColor=S.Accent;t.Location=new Point(110,10);Controls.Add(t);
            var p=S.Pnl(340,130);p.Location=new Point(25,45);
            p.Controls.Add(S.FLbl("Kullanici Adi:",15,15));var txtU=S.Tb(180);txtU.Location=new Point(140,15);p.Controls.Add(txtU);
            p.Controls.Add(S.FLbl("Yeni Sifre:",15,55));var txtP=S.Tb(180);txtP.Location=new Point(140,55);txtP.UseSystemPasswordChar=true;p.Controls.Add(txtP);
            p.Controls.Add(S.FLbl("Sifre Tekrar:",15,95));var txtP2=S.Tb(180);txtP2.Location=new Point(140,95);txtP2.UseSystemPasswordChar=true;p.Controls.Add(txtP2);
            Controls.Add(p);
            var kb=S.Btn("Sifirla",S.BtnGreen,130,38);kb.Location=new Point(50,195);
            kb.Click+=(s,e)=>{
                if(string.IsNullOrWhiteSpace(txtU.Text)||string.IsNullOrWhiteSpace(txtP.Text)){MessageBox.Show("Alanlari doldurunuz!");return;}
                if(txtP.Text!=txtP2.Text){MessageBox.Show("Sifreler uyusmuyor!");return;}
                try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("UPDATE Kullanicilar SET Sifre=@p WHERE KullaniciAdi=@u AND Aktif=1",cn);cmd.Parameters.AddWithValue("@p",txtP.Text);cmd.Parameters.AddWithValue("@u",txtU.Text);int r=cmd.ExecuteNonQuery();if(r>0){MessageBox.Show("Sifre basariyla degistirildi!");Close();}else MessageBox.Show("Kullanici bulunamadi!");}catch(Exception ex){MessageBox.Show(ex.Message);}
            };Controls.Add(kb);
            var ib=S.Btn("Geri",S.BtnDef,130,38);ib.Location=new Point(210,195);ib.Click+=(s,e)=>Close();Controls.Add(ib);
        }
    }

    // Duyurular ekrani
    public class DuyurularEkrani : Form
    {
        public DuyurularEkrani()
        {
            Text="Duyurular";Size=new Size(650,550);S.Apply(this);
            var t=S.Lbl("Duyurular",S.H1);t.ForeColor=S.Accent;t.Location=new Point(250,15);Controls.Add(t);
            var sp=new Panel{Location=new Point(30,60),Size=new Size(580,400),AutoScroll=true,BackColor=S.BG};Controls.Add(sp);
            try{using var cn=Db.Baglanti();cn.Open();using var cmd=new SqlCommand("SELECT d.Baslik,d.Icerik,d.OlusturmaTarihi,ISNULL(k.KullaniciAdi,'-') FROM Duyurular d LEFT JOIN Kullanicilar k ON d.OlusturanID=k.KullaniciID WHERE d.Aktif=1 ORDER BY d.OlusturmaTarihi DESC",cn);using var rd=cmd.ExecuteReader();int y=10,i=0;while(rd.Read()){var kp=new Panel{Location=new Point(5,y),Size=new Size(550,85),BackColor=i%2==0?S.Panel:Color.FromArgb(50,50,50)};kp.Paint+=(s,e)=>e.Graphics.FillRectangle(new SolidBrush(S.Accent),0,0,4,kp.Height);kp.Controls.Add(new Label{Text=rd.GetString(0),Font=new Font("Segoe UI",11,FontStyle.Bold),ForeColor=S.Accent,Location=new Point(15,8),AutoSize=true,MaximumSize=new Size(520,0)});var lc=new Label{Text=rd.GetString(1),Font=S.Small,ForeColor=S.Txt,Location=new Point(15,32),AutoSize=true,MaximumSize=new Size(520,0)};kp.Controls.Add(lc);kp.Controls.Add(new Label{Text=$"{rd.GetDateTime(2):dd.MM.yyyy} | {rd.GetString(3)}",Font=new Font("Segoe UI",8),ForeColor=S.Dim,Location=new Point(15,32+lc.PreferredHeight+5),AutoSize=true});kp.Height=40+lc.PreferredHeight+25;sp.Controls.Add(kp);y+=kp.Height+8;i++;}if(i==0){var l=S.Lbl("Henuz duyuru yok.");l.ForeColor=S.Dim;l.Location=new Point(200,180);sp.Controls.Add(l);}}catch{}
            var gb=S.Btn("Geri",S.BtnDef,150,40);gb.Location=new Point(245,475);gb.Click+=(s,e)=>Close();Controls.Add(gb);
        }
    }
}
