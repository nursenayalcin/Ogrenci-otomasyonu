using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class DuyurularEkrani : Form
    {
        public DuyurularEkrani()
        {
            Text = "Duyurular"; Size = new Size(650, 550); S.Apply(this);
            var t = S.Lbl("Duyurular", S.H1); t.ForeColor = S.Accent; t.Location = new Point(250, 15); Controls.Add(t);
            var sp = new Panel { Location = new Point(30, 60), Size = new Size(580, 400), AutoScroll = true, BackColor = S.BG }; Controls.Add(sp);
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using var cmd = new SqlCommand("SELECT d.Baslik,d.Icerik,d.OlusturmaTarihi,ISNULL(k.KullaniciAdi,'-') FROM Duyurular d LEFT JOIN Kullanicilar k ON d.OlusturanID=k.KullaniciID WHERE d.Aktif=1 ORDER BY d.OlusturmaTarihi DESC", cn);
                using var rd = cmd.ExecuteReader();
                int y = 10, i = 0;
                while (rd.Read())
                {
                    var kp = new Panel { Location = new Point(5, y), Size = new Size(550, 85), BackColor = i % 2 == 0 ? S.Panel : Color.FromArgb(50, 50, 50) };
                    kp.Paint += (s, e) => e.Graphics.FillRectangle(new SolidBrush(S.Accent), 0, 0, 4, kp.Height);
                    kp.Controls.Add(new Label { Text = rd.GetString(0), Font = new Font("Segoe UI", 11, FontStyle.Bold), ForeColor = S.Accent, Location = new Point(15, 8), AutoSize = true, MaximumSize = new Size(520, 0) });
                    var lc = new Label { Text = rd.GetString(1), Font = S.Small, ForeColor = S.Txt, Location = new Point(15, 32), AutoSize = true, MaximumSize = new Size(520, 0) }; kp.Controls.Add(lc);
                    kp.Controls.Add(new Label { Text = $"{rd.GetDateTime(2):dd.MM.yyyy} | {rd.GetString(3)}", Font = new Font("Segoe UI", 8), ForeColor = S.Dim, Location = new Point(15, 32 + lc.PreferredHeight + 5), AutoSize = true });
                    kp.Height = 40 + lc.PreferredHeight + 25;
                    sp.Controls.Add(kp); y += kp.Height + 8; i++;
                }
                if (i == 0) { var l = S.Lbl("Henuz duyuru yok."); l.ForeColor = S.Dim; l.Location = new Point(200, 180); sp.Controls.Add(l); }
            }
            catch { }
            var gb = S.Btn("Geri", S.BtnDef, 150, 40); gb.Location = new Point(245, 475); gb.Click += (s, e) => Close(); Controls.Add(gb);
        }
    }
}
