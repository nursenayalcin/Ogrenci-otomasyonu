using System;
using System.Drawing;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using OgrenciOtomasyonu.Utils;

namespace OgrenciOtomasyonu.Forms
{
    public class LoginEkrani : Form
    {
        private TextBox txtUser, txtPass, txtCode;
        private int n1, n2;
        private string rol;

        public LoginEkrani(string rol)
        {
            this.rol = rol;
            string rolTr = rol == "Ogrenci" ? "Ogrenci" : rol == "Akademisyen" ? "Akademisyen" : "Admin";
            Text = $"Giris - {rolTr}"; Size = new Size(500, 560); S.Apply(this);

            var t = S.Lbl("OGRENCI OTOMASYONU", S.H2); t.ForeColor = S.Accent; t.Location = new Point(125, 25); Controls.Add(t);
            var p = S.Pnl(380, 360); p.Location = new Point(55, 65);

            p.Controls.Add(S.Lbl("Kullanici Adi:")); p.Controls[0].Location = new Point(30, 25);
            txtUser = S.Tb(300); txtUser.Location = new Point(30, 50); p.Controls.Add(txtUser);
            p.Controls.Add(S.Lbl("Sifre:")); p.Controls[p.Controls.Count - 1].Location = new Point(30, 90);
            txtPass = S.Tb(300); txtPass.Location = new Point(30, 115); txtPass.UseSystemPasswordChar = true; p.Controls.Add(txtPass);
            p.Controls.Add(S.Lbl("Guvenlik Kodu:")); p.Controls[p.Controls.Count - 1].Location = new Point(30, 155);

            var r = new Random(); n1 = r.Next(10, 50); n2 = r.Next(10, 50);
            var q = new Label { Text = $"{n1}+{n2}=?", Font = new Font("Segoe UI", 11, FontStyle.Bold), ForeColor = Color.Orange, AutoSize = true, Location = new Point(30, 180) };
            p.Controls.Add(q);
            txtCode = S.Tb(100); txtCode.Location = new Point(130, 178); p.Controls.Add(txtCode);

            var gBtn = S.Btn("GIRIS", S.BtnBlue, 120, 38); gBtn.Location = new Point(240, 175); gBtn.Click += Giris; p.Controls.Add(gBtn);

            var link = new LinkLabel { Text = "Sifremi unuttum? / Sifre Sifirla", Font = S.Small, LinkColor = Color.FromArgb(150, 180, 220), AutoSize = true, Location = new Point(90, 225) };
            link.Click += (s, e) => MessageBox.Show("Sifre sifirlama baglantisi e-posta adresinize gonderilecektir.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            p.Controls.Add(link);

            var eBtn = S.Btn("E - DEVLET GIRIS", Color.FromArgb(150, 30, 30), 300, 40); eBtn.Location = new Point(40, 260);
            eBtn.Click += (s, e) => MessageBox.Show("e-Devlet ile giris yonlendirmesi yapilacaktir.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            p.Controls.Add(eBtn);

            var dBtn = S.Btn("Duyurular Icin Tiklayiniz", S.BtnDef, 250, 35); dBtn.Location = new Point(65, 310); dBtn.Font = S.Small;
            dBtn.Click += (s, e) => new DuyurularEkrani().ShowDialog(); p.Controls.Add(dBtn);

            Controls.Add(p); AcceptButton = gBtn;
        }

        private void Giris(object? s, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtUser.Text) || string.IsNullOrWhiteSpace(txtPass.Text))
            { MessageBox.Show("Kullanici adi ve sifre gerekli!", "Uyari", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; }
            if (!int.TryParse(txtCode.Text, out int c) || c != n1 + n2)
            { MessageBox.Show("Guvenlik kodu hatali!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
            try
            {
                using var cn = Db.Baglanti(); cn.Open();
                using var cmd = new SqlCommand("SELECT KullaniciID,Rol,IlgiliID FROM Kullanicilar WHERE KullaniciAdi=@u AND Sifre=@p AND Aktif=1", cn);
                cmd.Parameters.AddWithValue("@u", txtUser.Text); cmd.Parameters.AddWithValue("@p", txtPass.Text);
                using var rd = cmd.ExecuteReader();
                if (rd.Read())
                {
                    int uid = rd.GetInt32(0); string dbRol = rd.GetString(1);
                    int? ilgiliId = rd.IsDBNull(2) ? null : (int?)rd.GetInt32(2);
                    if (dbRol != rol) { MessageBox.Show("Bu kullanici bu rol tipinde degil!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                    rd.Close();
                    using var up = new SqlCommand("UPDATE Kullanicilar SET SonGirisTarihi=GETDATE() WHERE KullaniciID=@id", cn);
                    up.Parameters.AddWithValue("@id", uid); up.ExecuteNonQuery();

                    this.Hide();
                    Form menu;
                    if (dbRol == "Admin") menu = new AdminMenuEkrani(txtUser.Text);
                    else if (dbRol == "Akademisyen") menu = new OgretmenMenuEkrani(txtUser.Text, ilgiliId ?? 0);
                    else menu = new OgrenciMenuEkrani(txtUser.Text, ilgiliId ?? 0);
                    menu.FormClosed += (s2, e2) => this.Close();
                    menu.Show();
                }
                else MessageBox.Show("Kullanici adi veya sifre hatali!", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex) { MessageBox.Show(Db.HataMesaji(ex), "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error); }
        }
    }
}
